 /*!
@file main.c
@brief Cont�m a main do experimento 11
@author Rafael Cirino, Fernando Cillo
@date 16/06/2022
*/


#include "stdint.h"
#include "ISR.h"
#include "ISR.h"
#include "util.h"
#include "string.h"
#include "timers.h"
#include "UART.h"


#define BAUD_RATE 38400

/*!
 * @brief Variavel de configuracao de UART0
 */
UART0Config_type config0 = {
//		.bdh_sbns=0,		///< Um stop bit
		.bdh_sbns=1,		///< Dois stop bits
		.sbr=0b100, 		///< MCGFLLCLK/(baud_rate*osr)=4
		.c1_loops=0,		///< Operacao normal: full-duplex 
		.c1_dozeen=0,		///< UART habilitado no modo WAIT
		.c1_rsrc=0,			///< nao tem efeito para loops == 0
		.c1_m=0,			///< dados em 8 bits
		.c1_wake=0,			///< wakeup de RX por linha ociosa (IDLE)
		.c1_ilt=0,			///< deteccao do estado ocioso pela contagem apos start bits
		.c1_pe=0,			///< sem checagem de paridade por hardware
		.c1_pt=0,			///< bit de paridade par (sem efeito se pe==0)
		.c2_rwu=0,			///< operacao normal de recepcao do UART0
		.c2_sbk=0,			///< operacao normal de transmissor do UART0
		.s2_msbf=0,			///< envio de MSB para LSB
		.s2_rxinv=0,		///< polaridade dos dados de RX nao eh invertida
		.s2_rwuid=0,		///< nao tem efeito para rwu==0
		.s2_brk13=0,		///< nao tem efeito para operacao normal de transmissor
		.s2_lbkde=0,		///< deteccao do caractere break no tamanho menor
		.c3_r8t9=0,			///< nao tem efeito para m==0
		.c3_r9t8=0,			///< nao tem efeito para m==0
		.c3_txdir=0,		///< nao tem efeito para loops==0
		.c3_txinv=0,		///< polaridade dos dados de TX nao eh invertida 
		.c4_maen1=0,		///< todos os dados recebidos sao transferidos para buffer de dados
		.c4_maen2=0,			
		.c4_m10=0,			///< tamanho dos dados em RX e TX � 8 ou 9 bits
		.c4_osr=0b01111,	///< superamostragem 16x
		.c5_tdmae=0,		///< uso de DMA pelo TX desabilitada
		.c5_rdmae=0,		///< uso de DMA pelo RX desabilitado
		.c5_bothedge=0,		///< amostragem somente na borda de subida do clock
		.c5_resyncdis=0		///< resincronizacao na recepcao habilitada
};

/*!
 * @brief Variavel de configuracao de UART2
 */
UARTConfig_type config2 = {
//		.bdh_sbns=0,		///< Um stop bit
		.bdh_sbns=1,		///< Dois stop bits
		.sbr=0b100, 		///< MCGFLLCLK/(baud_rate*osr)=4
		.c1_loops=0,		///< Operacao normal: full-duplex 
		.c1_uartswai=0,		///< clock de UART continua correndo no modo WAIT
		.c1_rsrc=0,			///< nao tem efeito para loops == 0
		.c1_m=0,			///< dados em 8 bits
		.c1_wake=0,			///< wakeup de RX por linha ociosa (IDLE)
		.c1_ilt=0,			///< deteccao do estado ocioso pela contagem apos start bits
		.c1_pe=0,			///< sem checagem de paridade por hardware
		.c1_pt=0,			///< bit de paridade par (sem efeito se pe==0)
		.c2_rwu=0,			///< operacao normal de recepcao do UART0
		.c2_sbk=0,			///< operacao normal de transmissor do UART0
		.s2_rxinv=0,		///< polaridade dos dados de RX nao eh invertida
		.s2_rwuid=0,		///< nao tem efeito para rwu==0
		.s2_brk13=0,		///< nao tem efeito para operacao normal de transmissor
		.s2_lbkde=0,		///< deteccao do caractere break no tamanho menor
		.c3_r8=0,			///< precisa ser lido para completar o MSB dos dados quando m == 1
		.c3_t8=0,			///< precisa ser setado com o MSB dos dados quando m == 1
		.c3_txdir=0,		///< nao tem efeito para loops==0
		.c3_txinv=0,		///< polaridade dos dados de TX nao eh invertida 
		.c4_tdmas=0,		///< selecionar transmissor para transferencia DMA
		.c4_rdmas=0 		///< selecionar receptor para transferencia DMA
};

void config_uart(){
	/*!
	 * Seta o divisor de frequencia do barramento
	 */
	SIM_setaOUTDIV4 (0b001);
	
	/*!
	 * Configurar UART0 com Rx e Tx habilitados: SBR tem que ser aproximado para maior que baud rate setado
	 */
	config0.sbr = (uint16_t)(20971520./(BAUD_RATE * (config0.c4_osr+1)));
	if ((20971520./(1.0 * BAUD_RATE * (config0.c4_osr+1))) > config0.sbr)
		config0.sbr++;
	UART0_initTerminal (&config0);

	/*!
	 * Ativa IRQs
	 */
	UART0_ativaIRQTerminal (0);

	// Setup
	ISR_inicializaBC();
	
	/*!
	 * Habilita a interrupcao do Rx do UART0
	 */
	UART0_ativaInterruptRxTerminal();
	//UART0_ativaInterruptTxTerminal();
	
	ISR_EnviaString ("\n\r");
}


int main(){
	config_uart();
	
	char s_entrada[20];
	char result[20] = "";
	
	char* op;
	float fvalor = 0;
	int ivalor = 0;
	int check = 0;
	
	char s_inicio[51] = "Entre <op1> <op> <op2> (<op>: +,-,*,/,%,#,&,|)\n\r";
	char s_erro[58] = "Expressao incorreta. Tente novamente <op1> <op> <op2>\n\r";
	char s_erro_op[64] = "Operador incorreto. Tente novamente (<op>: +,-,*,/,%,#,&,|)\n\r";
	
	estado_type estado_atual = ISR_LeEstado();
	estado_type estado_anterior = RESULTADO;
	
	
	for(;;){
		estado_atual = ISR_LeEstado();
		
		if (estado_atual != estado_anterior){
			estado_anterior = estado_atual;
			
			switch(estado_atual){
				case INICIO:
					ISR_AtualizaEstado(MENSAGEM);
					break;
				case MENSAGEM:
					ISR_EnviaString (s_inicio);
					break;
				case EXPRESSAO:
					break;
				case CALCULO:
					ISR_extraiString(s_entrada);
					check = atoOp(s_entrada, op, &fvalor, &ivalor);
					
					if (check > 0){
						ISR_AtualizaEstado(RESULTADO);
						
						if (check == 1){
							ftoa(fvalor, result);
						} else if (check == 2){
							itoa(ivalor, result, 10);
						}
						
					} else{
						ISR_AtualizaEstado(ERRO);
					}
					break;
				case RESULTADO:
					ISR_EnviaString("\n\r= ");
					ISR_EnviaString(result);
					ISR_EnviaString("\n\r");
					break;
				case ERRO:
					ISR_EnviaString("\n\r");
					if (check == -1){
						ISR_EnviaString(s_erro);
					} else if (check == -2){
						ISR_EnviaString(s_erro_op);
					}
					break;
			}
		}
	}
	
	return 0;
}
