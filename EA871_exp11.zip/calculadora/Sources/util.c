/*!
 * @file util.c
 * @brief Este modulo contem as funcoes de uso frequente
 * @author Wu Shin Ting
 * @date 27/02/2022
 */

#include "stdlib.h"
#include "string.h"
#include "math.h"
#include "ctype.h"

int atoOp (char string[], char *op, float *fvalor, int *ivalor){
	char* str;
	const char espaco[1] = " ";

	int i = 0;
	float oper_f[3];
	int oper_i[3];
	
	for(str=strtok(string, espaco); str!=0; str=strtok(0, espaco)){
	  if ((i == 0) || (i==2)){
	      if(isdigit(*str) != 0){
	          oper_f[i] = atof(str);
	          oper_i[i] = atoi(str);
	      } else{
	          return -1;
	      }
	      } else if (i==1){
	          if(isdigit(*str) == 0){
	            op = str;
	          } else{
	              return -1;
	          }
	      } else if (i > 2){
	          return -1;
	      }
	  
	  i += 1;
	}
	
	if (i < 2){
	  return -1;
	}
	
	
	switch(*op){
		case '/':
			*fvalor = oper_f[0] / oper_f[2];
            return 1;
		case '+':
			*fvalor = oper_f[0] + oper_f[2];
			return 1;
		case '*':
			*fvalor = oper_f[0] * oper_f[2];
			return 1;
		case '-':
			*fvalor = oper_f[0] - oper_f[2];
			return 1;
		case '#':
            *ivalor = oper_i[0] / oper_i[2];
            return 2;
       case '%':
            *ivalor = oper_i[0] % oper_i[2];
            return 2;
       
       case '&':
            *ivalor = oper_i[0] & oper_i[2];
            return 2;
       case '|':
            *ivalor = oper_i[0] | oper_i[2];
            return 2;
      }
	return -2;
}

char *itoa (int n, char *string, char b)
{
	char sinal;
	unsigned short i, j, a;
	unsigned int m;
	
	if (n == 0) {
		///< Tratamento do caso especial
		string[0] = '0';
		string[1] = '\0';
		return string;
	}
	
	if (n < 0) sinal = 1;
	else sinal = 0;
	
	/*!
	 * Converter para codigos ASCII, digito por digito, de menos 
	 * significativo para o mais
	 */ 
	i = 0;
	m = abs(n);
	
	while (m != 0) {
		a = m%b;
		string[i+sinal] = (a>9)?(a-10)+'A' : a+'0';
		i++;
		m = m/b;
	}
	string[i+sinal] = '\0';			///< Incluir terminador
	
	///< Reverter a sequencia
	j = strlen(string)-1;
	i = sinal;
			
	while (j > i) {
		char tmp = string[i];
		string[i] = string[j];
		string[j] = tmp;
		i++;
		j--;
	}
	
	///< Adicionar o sinal negativo caso necessario
	if (sinal) string[0] = '-';
	
	return string;
}

char *ftoa(float value, char *string){
	char string_decimal[2];
	int v_int = value;
	
	//Parte inteira
	itoa(v_int, string, 10);
	uint16_t len_str = strlen(string);
	string[len_str] = '.';
	
	//Arredondando
	uint16_t v_decimal = (value - v_int) * pow(10,2);
	
	uint16_t v_arredond = (value - v_int) * pow(10,3) - v_decimal * pow(10,1);
	if (v_arredond > 4){
		v_decimal +=1;
	}
	
	//Parte decimal
	itoa(v_decimal, string_decimal, 10);
	
	if (strlen(string_decimal) == 1){
		string[len_str + 1] = '0';
		string[len_str + 2] = string_decimal[0];
	} else {
		string[len_str + 1] = string_decimal[0];
		string[len_str + 2] = string_decimal[1];
	}
	
	string[len_str + 3] = '\0';
	
	return string;
}
