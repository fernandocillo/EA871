 /*!
@file ISR.c
@brief Cont�m as interrup��es
@author Rafael Cirino, Fernando Cillo
@date 16/06/2022
*/


#include "derivative.h"
#include "UART.h"
#include "buffer_circular.h"
#include "ISR.h"

#define TAM_MAX 128
static estado_type estado = INICIO;
static BufferCirc_type bufferE;
static BufferCirc_type bufferS;


estado_type ISR_LeEstado () {
	return estado;
}

void ISR_AtualizaEstado (estado_type novo) {
	estado = novo;
	return;
}

void ISR_extraiString (char *string) {
	uint8_t i=0;
	BC_pop (&bufferE, &string[i]);
	while (string[i] != '\0') {
		BC_pop (&bufferE, &string[++i]);				
	}
}

void ISR_inicializaBC () {
	/*!
	 * Inicializa um buffer circular de entrada
	 */
	BC_init(&bufferE, TAM_MAX);

	/*!
	 * Inicializa dois buffers circulares de saida
	 */
	BC_init(&bufferS, TAM_MAX);
}

void ISR_EnviaString (char *string) {
	uint8_t i;
	
	while (BC_push( &bufferS, string[0])==-1);
	UART0_C2 |= UART0_C2_TIE_MASK;
	i=1;
	while (string[i] != '\0') {
		while (BC_push( &bufferS, string[i])==-1);
		i++;
	}
}

uint8_t ISR_BufferSaidaVazio () {
	return BC_isEmpty (&bufferS);
}

/*!
 * @brief Rotina de servi�o de UART0
 */
void UART0_IRQHandler()
{
	char item;

	if (UART0_S1 & UART0_S1_RDRF_MASK) {
		/*!
		 * Interrupcao solicitada pelo canal Rx
		 */
		char r;

		r = UART0_D;

		if (estado != EXPRESSAO) {
			//Liberar o canal para novas recepcoes
			return;
		}
		
		UART0_D = r; //Ecoar o caractere
		
		//Adicionar no buffer circular de entrada
		if (r == '\r') {
			//inserir o terminador e avisar o fim de uma string
			BC_push (&bufferE, '\0');
			while (!(UART0_S1 & UART_S1_TDRE_MASK));
			UART0_D = '\r';
			UART0_D = '\n';
			
			estado = CALCULO;
		} else {
			BC_push (&bufferE, r);
		}
	}
	else if (UART0_S1 & UART0_S1_TDRE_MASK) {
		/*!
		 * Interrupcao solicitada pelo canal Tx
		 */
		if (BC_isEmpty(&bufferS)){
			UART0_C2 &= ~UART0_C2_TIE_MASK;     ///< desabilita Tx quando nao ha dado para envio
		
			if (estado == RESULTADO) {
				estado = INICIO;
				return;
			} 
			
			if ((estado == ERRO) || (estado == MENSAGEM)) {
				estado = EXPRESSAO;
				return;
			}
		}
		else {
			BC_pop (&bufferS, &item);
			UART0_D = item;
		}
	} 
}
