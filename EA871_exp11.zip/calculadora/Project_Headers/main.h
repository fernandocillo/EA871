/*!
@file main.h
@brief Cont�m a main do experimento 11
@author Rafael Cirino, Fernando Cillo
@date 16/06/2022
*/

#ifndef MAIN_H_
#define MAIN_H_

/*!
 * @brief Configura a inicializa��o do m�dulo UART
 */
void config_uart();

/*!
 * @brief Programa do roteiro 11
 */
int main();

#endif /* MAIN_H_ */
