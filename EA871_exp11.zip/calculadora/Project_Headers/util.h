/*!
 * @file util.h
 * @brief Este modulo contem as funcoes de uso frequente
 * @author Wu Shin Ting
 * @date 27/02/2022
 */

#ifndef UTIL_H_
#define UTIL_H_

#include "UART.h"

/*!
 * @brief Converte de string para float ou inteiro
 * @param[in] string: Vari�vel que armazenar� o texto convertido
 * @param[in] op: Armazenar a opera��o a ser realizada
 * @param[in] fvalor: Resultado final em float
 * @param[in] ivalor: Resultado final em inteiro
 * return erro
 */
int  atoOp (char *string, char *op, float *fvalor, int *ivalor);

/*!
 * @brief Converte de float para string
 * @param[in] value: valor float que ser� convertido
 * @param[in] string
 * return float em string
 */
char *ftoa(float value, char *string);

/*!
 * @brief convert a unsigned integer number into a string
 * @param[in] n number
 * @param[in] b system base
 * @param[out] string converted number
 */
char *itoa (int n, char *string, char b);



#endif /* UTIL_H_ */
