
// Fun��o de atraso para podermos visualizar a cor do LED alternando
void delay_10us(unsigned int i)
{
	__asm__(
	"delay:\n"							  
		"push {r2,r3,lr}\n"					 
		
	"	mov  r3, #0\n"					     
	"iteracao:\n"
	"	mov	r2, #25\n"	
	"laco:\n"
		"add		r3, #0\n"
		"sub		r3, #0\n"
		"add		r3, #0\n"
		"sub		r3, #0\n"
		"add		r3, #0\n"
		"sub 	r2,#1\n"	
										  
		"bne 	laco\n"
									
		"sub	r0, #1\n"
		"bne	iteracao \n"
		
		"pop 	{r2,r3,pc}\n"	
	);
}


// Fun��o para setar o LED vermelho (ativo alto)
void vermelho(int set){
	// Modulo PORT
	(*(unsigned int volatile *) 0x4004a048u) = (*(unsigned int volatile *) 0x4004a048u) & 0xFFFFF8FF; // Zera os bits #8, #9 e #10
	(*(unsigned int volatile *) 0x4004a048u) = (*(unsigned int volatile *) 0x4004a048u) | 0x00000100; // Seta o bit #8 do multiplexador 
	// Modulo GPIO
	(*(unsigned int volatile *) 0x400ff054u ) = (*(unsigned int volatile *) 0x400ff054u )  | (1<<18);
	if (set==1) { // Se vermelho(1) -> led acende
			(*(unsigned int volatile *) 0x400FF048u) = (1<<18); 
		}
		else { // Se vermelho(0) -> led apaga
			(*(unsigned int volatile *) 0x400FF044u) = (1<<18);
		}	
}

// Fun��o para setar o LED azul (ativo alto)
void azul(int set){
	// PORT
	(*(unsigned int volatile *) 0x4004c004u ) = (*(unsigned int volatile *) 0x4004a048u) & 0xFFFFF8FF; // Zera os bits #8, #9 e #10
	(*(unsigned int volatile *) 0x4004c004u ) = (*(unsigned int volatile *) 0x4004a048u) | 0x00000100; // Seta o bit #8 do multiplexador 
	//GPIO
	(*(unsigned int volatile *) 0x400ff0d4u ) = (*(unsigned int volatile *) 0x400ff054u )  | (1<<1); 
			
	if (set==1) { // Se azul(1) -> led acende
		(*(unsigned int volatile *) 0x400ff0c8u ) = (1<<1); 
	}
	else { // Se azul(0) -> led apaga
		(*(unsigned int volatile *) 0x400ff0c4u ) = (1<<1);
	}
	
}

// Fun��o para setar o LED verde (ativo alto)
void verde(int set){
	// PORT
	(*(unsigned int volatile *) 0x4004a04cu ) = (*(unsigned int volatile *) 0x4004a048u) & 0xFFFFF8FF; // Zera os bits #8, #9 e #10
	(*(unsigned int volatile *) 0x4004a04cu ) = (*(unsigned int volatile *) 0x4004a048u) | 0x00000100; // Seta o bit #8 do multiplexador 
	//GPIO
	(*(unsigned int volatile *) 0x400ff054u) = (*(unsigned int volatile *) 0x400ff054u )  | (1<<19); 
			
	if (set==1) { // Se verde(1) -> led acende
		(*(unsigned int volatile *) 0x400FF048u) = (1<<19); 
	}
	else { // Se verde(0) -> led apaga
		(*(unsigned int volatile *) 0x400FF044u) = (1<<19);
	}
	
}


int main(void)
{
	
	(*(unsigned int volatile *) 0x40048038u) =  (*(unsigned int volatile *) 0x40048038u)| (1<<10); 
	(*(unsigned int volatile *) 0x40048038u) =  (*(unsigned int volatile *) 0x40048038u)| (1<<12); 
	 
	
	// La�o que alterna as cores do LED
	for(;;) {
		// Acende o LED na cor vermelho
		azul(0);
		verde(0);
		vermelho(1);
		delay_10us(52000); 
		
	 	// Acende o LED na cor verde
		vermelho(0);
		azul(0);
		verde(1);
		delay_10us(52000); 
		
		// Acende o LED na cor azul
		vermelho(0);
		verde(0);
		azul(1);
		delay_10us(52000); 
		
		// Acende o LED na cor amarela
		azul(0);
		verde(1);
		vermelho(1);
		delay_10us(52000); 
		
		// Acende o LED na cor branca
		vermelho(1);
		azul(1);
		verde(1);
		delay_10us(52000); 
		
		
	}
	
	return 0;
}


