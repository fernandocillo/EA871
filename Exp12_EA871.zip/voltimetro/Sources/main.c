/*!
@file main.c
@brief Cont�m a main do experimento 12
@author Rafael Cirino, Fernando Cillo
@date 16/06/2022
*/

#include "ADC.h"
#include "timers.h"
#include "GPIO_latch_lcd.h"
#include "GPIO_ledRGB.h"
#include "ISR.h"
#include "util.h"
#include "GPIO_switches.h"

//#define MAX 0xff			///< resolucao 8 bits 

/*!
 * @var config
 * @brief Inicializar os parametros de configuracao do modulo ADC0
 * @note Ver secao 28.4.4.5 (pagina 487) do manual 
 * https://www.dca.fee.unicamp.br/cursos/EA871/references/ARM/KL25P80M48SF0RM.pdf
 */
ADCConfig config = {
		.sc1_diff=0,      		///< conversao unipolar (0) ou diferencial (1)
		.cfg1_adlpc=0,			///< potencia normal
		.cfg1_adiv=0b10,		///< inputclock/8
//		.cfg1_adlsmp=0, 		///< tempo de amostragem curto
		.cfg1_adlsmp=1, 		///< tempo de amostragem longo
		.cfg1_mode=0b01,		///< 8 bits (unipolar)/9 bits (bipolar)
		.cfg1_adiclk=0b01,		///< bus clock
		.cfg2_muxsel=0, 		///< canal A (0)
		.cfg2_adacken=0,		///< desabilitar a saida de sinal de clock assincrono
//		.cfg2_adhsc=0,			///< desabilitar operacao em alta velocidade
		.cfg2_adhsc=0,			///< habilitar operacao em alta velocidade
		.cfg2_adlsts=0b11, 		///< tempo de amostragem mais longo
		.sc2_adtrg=0,			///< trigger por software
		.sc2_acfe=0, 		    ///< desabilitar funcao de comparacao em igualdade
		.sc2_acfgt=0,			///< desabilitar funcao de comparacao em desigualdade
		.sc2_acren=0,			///< desabilitar comparacao de uma faixa
		.sc2_dmaen=0, 			///< habilitar de DMA
		.sc2_refsel=0b00,		///< tensoes de referencia VREFH e VREFL
		.sc3_adco=0,			///< amostragem unica
		.sc3_avge=1, 			///< habilitar media de amostras por hardware
//		.sc3_avgs=0b01 			///< 8 amostras
		.sc3_avgs=0b10 			///< 32 amostras
};

ADCConfig config_roteiro = {
		.sc1_diff=0,      		///< conversao unipolar (0) ou diferencial (1)
		.cfg1_adlpc=0,			///< potencia normal
		.cfg1_adiv=0b11,		///< 4
//		.cfg1_adlsmp=0, 		///< tempo de amostragem curto
		.cfg1_adlsmp=1, 		///< tempo de amostragem longo
		.cfg1_mode=0b01,		///< 8 bits (unipolar)/9 bits (bipolar)
		.cfg1_adiclk=0b01,		///< bus clock/2
		.cfg2_muxsel=0, 		///< canal A (0)
		.cfg2_adacken=0,		///< desabilitar a saida de sinal de clock assincrono
//		.cfg2_adhsc=0,			///< desabilitar operacao em alta velocidade
		.cfg2_adhsc=0,			///< habilitar operacao em alta velocidade
		.cfg2_adlsts=0b11, 		///< tempo de amostragem mais longo
		.sc2_adtrg=0,			///< trigger por software
		.sc2_acfe=0, 		    ///< desabilitar funcao de comparacao em igualdade
		.sc2_acfgt=0,			///< desabilitar funcao de comparacao em desigualdade
		.sc2_acren=0,			///< desabilitar comparacao de uma faixa
		.sc2_dmaen=0, 			///< habilitar de DMA
		.sc2_refsel=0b00,		///< tensoes de referencia VREFH e VREFL
		.sc3_adco=0,			///< amostragem unica
		.sc3_avge=1, 			///< habilitar media de amostras por hardware
//		.sc3_avgs=0b01 			///< 8 amostras
		.sc3_avgs=0b10 			///< 32 amostras
};

void main_init(){
	/*!
		 * Seta o divisor de frequencia do sinal do barramento
		 */ 
		SIM_setaOUTDIV4 (0b001);

		/*!
		 * Configura os pinos do Latch 74751
		 */
		GPIO_ativaConLatchLCD ();


		/*!
		 * Configura o timer PIT
		 */
		//PIT_initSemAtivacaoTimer0(10485760); 	
		PIT_initSemAtivacaoTimer0(20971520*3);

		/*!
		 * Configura ADC0 com os parametros especificados
		 */
		ADC0_init(&config);		

		/*!
		 * Associa pinos fisicos aos canais do ADC0
		 */
		ADC0_connectPTB1ToChannel ();

		/*!
		 * Disparo de amostragem em ADC0 por hardware (PIT0): chamar depois de inicializar ADC
		 */
		
		ADC0_initADHWT(0b100);
		
		GPIO_escreveByteLatch(0x00); 				//!< /li /l apagar os leds vermelhos
		ADC0_selChannel (0b11010); //!< \li \l selecionar o canal do sensor AN3031
		
		ADC0_ativaIRQ(2);
		PIT_ativaIRQ(1);

		/*!
		 * Ativa PIT
		 */
		PIT_ativaTimer0();
		
		SysTick_init(10485760/2);
}

void lcd_switch_rgb_init(){
	GPIO_ativaConLCD ();
	GPIO_initLCD ();
	
	GPIO_initSwitches();
	GPIO_habilitaSwitchesInterrupt(3);
			
	GPIO_initLedRGB();
	
	
}



int main(void)
{
	lcd_switch_rgb_init();
			
	float mV;
	float temp;
	uint16_t amostras[2] = {0, 0};
	
	estado_type estado_atual = ISR_LeEstado();
	estado_type estado_anterior = ESPERA;
	
	main_init();
	
	char string[5];
	
	GPIO_escreveStringLCD (0x02, "TENSAO");
	
	for(;;) {
		estado_atual = ISR_LeEstado();
		
		if (estado_atual != estado_anterior){
			estado_anterior = estado_atual;
			
			switch(estado_atual){
				case ESPERA:
				case LEITURA:
				case AMOSTRA_VOLT:
				case AMOSTRA_TEMP:
					break;
				case TENSAO:
					ISR_LeValoresAmostrados (amostras);
					codigo2tensao (amostras[0], &mV);
					ftoa(mV, string);
					GPIO_escreveStringLCD (0x09, string);
					
					ISR_AtualizaEstado (LEITURA);
					break;
				case TEMPERATURA:
					ISR_LeValoresAmostrados (amostras);
					AN3031_temperatura (amostras[1], &temp);
					ftoa(temp, string);
					GPIO_escreveStringLCD (0x4b, string);
					
					if (temp > 24){
						GPIO_ledRGB(ON, OFF, OFF);
					} else{
						GPIO_ledRGB(OFF, OFF, OFF);
					}
					
					ISR_AtualizaEstado (ESPERA);
					GPIO_initSwitches();
					GPIO_habilitaSwitchesInterrupt(3);
					break;
				case LIMPA_LINHA:
					GPIO_escreveStringLCD (0x09, "    ");
					
					ISR_AtualizaEstado (ESPERA);
					break;
				
			}	
		}
	}
	
	return 0;
}

