/*!
	@file ISR.c
	@brief Este modulo contem as interrup��es
	@author Rafael Cirino, Fernando Cillo
	@date 16/06/2022
*/

#include "derivative.h"
#include "ISR.h"
#include "ADC.h"
#include "timers.h"
#include "GPIO_switches.h"

static uint16_t valor[2];		///< valor convertido do sensor LM61
static estado_type estado = ESPERA;
static uint8_t contador = 0;

void ADC0_IRQHandler(void) {
	if( ADC0_SC1A & ADC_SC1_COCO_MASK )
	{	
		switch (estado){
			case AMOSTRA_TEMP:
				valor[1] = ADC0_RA;
				
				estado = TEMPERATURA;
				break;
			case AMOSTRA_VOLT:
				valor[0] = ADC0_RA;
				
				contador = 0;
				SysTick_ativaInterrupt ();
				
				estado = TENSAO;
				break;
		}
	}
}

void PIT_IRQHandler(void) {
	PIT_TFLG0 |= PIT_TFLG_TIF_MASK;     //!< \li \l w1c (limpa pendencias)
	
	switch (estado){
		case ESPERA: //[0,0]
			GPIO_desabilitaSwitchesInterrupt ();
			estado = AMOSTRA_TEMP;
		break;
	}
}

void PORTA_IRQHandler (void)
{	
	int valor;
	GPIO_leSwitchesISF(&valor);
	
	switch (estado){
		case ESPERA: //[0,0]
			if (valor == 0x2) {
				estado = AMOSTRA_VOLT;
				
				ADC0_SC2 &= ~ADC_SC2_ADTRG_MASK; //!< \li \l chavear para trigger por software
				ADC0_selChannel (0b01001);
			}
		break;
	}
}

void SysTick_Handler(void){	
	if((contador > 8) && (estado == LEITURA)){
		SysTick_desativaInterrupt ();
		estado = LIMPA_LINHA;
		
		ADC0_SC2 |= ADC_SC2_ADTRG_MASK; //!< \li \l chavear para trigger por hardware
		ADC0_selChannel (0b11010); //!< \li \l selecionar o canal do sensor AN3031
	}
	contador++;
}


estado_type ISR_LeEstado() {
	return estado;
}

void ISR_AtualizaEstado (estado_type novo) {
	estado = novo;
	
	return;
}

void ISR_LeValoresAmostrados (uint16_t *v) {
	v[0] = valor[0];
	v[1] = valor[1];
	
	return;
}
