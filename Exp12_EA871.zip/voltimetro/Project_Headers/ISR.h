/*!
	@file ISR.h
	@brief Este modulo contem declaracoes relacionadas com o modulo ISR.c
	@author Rafael Cirino, Fernando Cillo
	@date 16/06/2022
*/

#ifndef ISR_H_
#define ISR_H_

typedef enum state_tag {
	ESPERA,
	AMOSTRA_TEMP,
	AMOSTRA_VOLT,
	TEMPERATURA,
	TENSAO,
	LEITURA,
	LIMPA_LINHA
} estado_type;

/*!
 * @brief Le o estado do aplicativo
 */
estado_type ISR_LeEstado ();

/*!
 * @brief Atualiza o estado do aplicativo
 * @param[in] novo estado
 */
void ISR_AtualizaEstado (estado_type novo);

/*!
 * @brief Le o valor amostrado em ADC0_RA
 * @param[in] v: Armazena o valor amostrado
 */
void ISR_LeValoresAmostrados (uint16_t *v);


#endif /* ISR_H_ */
