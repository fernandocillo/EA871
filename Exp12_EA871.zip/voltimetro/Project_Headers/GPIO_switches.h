/*!
@file GPIO_switches.h
@brief Este m�dulo cont�m interface aos registradores de
switches no modo GPIO
@author Rafael Cirino, Fernando Cillo
@date 27/04/2022
*/

#ifndef GPIO_SWITCHES_H_
#define GPIO_SWITCHES_H_

#include "util.h"

void GPIO_desabilitaSwitchesInterrupt ();

/*!
 * @brief Verifica qual bot�o est� sendo acionado 
 * @param[in] valor: endere�o da vari�vel valor
*/
void GPIO_leSwitchesISF (int *valor);

/*!
 * @brief Inicaliza a interrupa��o pelas portas NMI, IRQA5, IRQA12
*/
void GPIO_habilitaSwitchesInterrupt (uint8_t priority);

/*!
 * @brief Inicaliza os bot�es ligados as portas NMI, IRQA5, IRQA12
*/
void GPIO_initSwitches();

/*!
 * @brief Faz a leitura do bot�o conectado na sa�da NMI
 * param[out] ON/OFF
*/
booleano_type GPIO_amostraBotoeiraNMI ();

/*!
 * @brief Faz a leitura dos bot�es e armazena o resultado de entrada no endere�o apontado por valor
 * param[int] valor endere�o de mem�ria
*/
void GPIO_amostraSwitches(int *valor);

#endif /* GPIO_SWITCHES_H_ */
