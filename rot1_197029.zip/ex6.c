/* EA871 - Laboratório de Programação Básica de Sistemas Digitais */
/* Fernando Teodoro de Cillo	RA 197029	Turma Q */
/* Roteiro 1 */

#include <stdio.h>

int main() {
  int n,         /* guarda o numero de alunos      */
      nota,      /* usada para a leitura das notas */
      contador,  /* numero de notas ja' lidas      */
      notamaior, /* guarda a maior nota            */
      notamenor; /* gurada a menor nota            */ 
  
  printf("\n\tCalculo de maior e menor nota de uma turma\n");
  printf("\nDigite o numero de alunos: ");
  scanf("%d", &n);
  
  /* inicializacoes */
  contador = 0;
  notamaior = 0;
  notamenor = 100;
  
  while (contador <  n) {
    printf("Digite uma nota (0 a 100): "); 
    scanf("%d", &nota);   /* Correção do código: ¬a => &nota */
    contador = contador + 1;
    if (notamaior < nota)
      notamaior = nota;
    if (notamenor > nota)
      notamenor = nota;
  }
  
  printf("A maior nota obtida foi: %d\n", notamaior);
  printf("A menor nota obtida foi: %d\n", notamenor);
  
  return 0;
}