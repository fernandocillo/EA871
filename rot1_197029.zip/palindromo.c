/* EA871 - Laboratório de Programação Básica de Sistemas Digitais */
/* Fernando Teodoro de Cillo	RA 197029	Turma Q */
/* Roteiro 1 */

#include <stdio.h>
#include <string.h> /* Biblioteca que permite realizar operações com strings */

int main()
{
	char palavra[50]; /* A maior palavra registrada da língua portuguesa possui 46 letras => 50 caracteres bastam*/
 

	printf("VERIFICADOR DE PALINDROMOS: \n\n");
	printf("Qual a palavra a ser analisada?\n\n");
	scanf("%s", palavra); /* Possível palíndromo a ser verificado */
	int carac = strlen(palavra); /* Número de caracteres na string é o tamanho da palavra */
	printf("\n");


    for (int cont = 0; cont < carac/2; cont++) { /* Como duas letras serão analisadas por iterações, só precisamos de metade */
        if (palavra[cont] != palavra[carac - cont - 1]){ /* Verifica se a letra mais a esquerda difere da mais 
        a direita (desconsiderando as já verificadas) */
            printf("%s não é palindromo", palavra); /* Se alguma diferença for encontrada, não é um palíndromo */
            return 0;
        }
    }
    printf("%s eh palindromo", palavra);/* Se não houver diferença, a palavra é igual de trás-para-frente (palíndromo) */

	return 0;
}