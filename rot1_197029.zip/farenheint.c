/* EA871 - Laboratório de Programação Básica de Sistemas Digitais */
/* Fernando Teodoro de Cillo	RA 197029	Turma Q */
/* Roteiro 1 */

#include <stdio.h>

int main() {
	float celsius, farenheit; /* Definição da tipagem das variáveis */

	printf("CONVERSOR DE TEMPERATURA: \n\n");
	printf("Insira uma temperatura em Farenheit:\n\n");
	scanf("%f", &farenheit); /* Armazena um valor (em °F) no endereço 
	reservado para a variável farenheit */

	celsius = (farenheit-32) * 5/9; /* Converte para °C */

	printf("%.2f F = %.2f C", farenheit, celsius);
	/* %.2f identifica uma variável float com duas casas decimais */

	return 0;
}