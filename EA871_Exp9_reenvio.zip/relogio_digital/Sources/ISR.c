/*!
@file ISR.c
@brief O m�dulo cont�m fun��es de interrup��o
@author Rafael Cirino, Fernando Cillo
@date 15/05/2022
*/

#include "util.h"
#include "ISR.h"
#include "timers.h"
#include "derivative.h"
#include "GPIO_switches.h"
#include "GPIO_latch_lcd.h"

	
static estado_type estado = NORMAL;
static uint32_t segundos;
static uint32_t hor[4] = {0, 0, 0, 0};

static uint8_t contador;

static int valor;

estado_type ISR_LeEstado ()
{
	return estado;
}

void ISR_EscreveEstado (estado_type w_estado)
{
	estado = w_estado;
}

void ISR_LeHorario(uint32_t* segundos){
	dhms2s (hor[3], hor[0], hor[1], hor[2], segundos);
}

void SysTick_Handler(void){
	ISR_LeHorario(&segundos);
	
	
	if((contador > 5) && (estado != NORMAL)){
		RTClpo_setTime (segundos);
		GPIO_desativaCursorPiscanteLCD();
		SysTick_desativaInterrupt ();
		
		estado = NORMAL;
	}
	contador++;
}

int8_t troca_estado(uint8_t e_nmi, uint8_t e_i5, uint8_t e_i12){
	int8_t j = 0;
	
	if (valor == 0x1) {
		estado = e_nmi;
	} else if (valor == 0x2) {
		estado = e_i5;
		j = -1;
	} else if (valor == 0x100) {
		estado = e_i12;
		j = 1;
	}
	contador = 0;
	
	return j;
}

void PORTA_IRQHandler (void){
	GPIO_leSwitchesISF(&valor);
	
	int8_t j;
	switch(estado){
		case NORMAL:
			troca_estado(NORMAL_HORA, NORMAL, NORMAL);
			if (valor == 0x1) {
				ISR_carregaHorario();
			}
			break;
		case SEGUNDO_HORA:
		case NORMAL_HORA:
			break;
		case HORA_MINUTO:
			break;
		case MINUTO_SEGUNDO:
			break;
		case HORA:
		case DECREMENTA_HORA:
		case INCREMENTA_HORA:
			j = troca_estado(HORA_MINUTO, DECREMENTA_HORA, INCREMENTA_HORA);
			if ((hor[0] == 0) && (j == -1)){
				hor[0] = 23;
			}
			else{
				hor[0] += j;
			}
			break;
		case MINUTO:
		case DECREMENTA_MINUTO:
		case INCREMENTA_MINUTO:
			j = troca_estado(MINUTO_SEGUNDO, DECREMENTA_MINUTO, INCREMENTA_MINUTO);
			if ((hor[1] == 0) && (j == -1)){
				hor[1] = 59;
			}
			else if ((hor[1] == 59) && (j == 1)){
				hor[1] = 0;
			}
			else{
				hor[1] += j;
			}
			break;
		case SEGUNDO:
		case DECREMENTA_SEGUNDO:
		case INCREMENTA_SEGUNDO:
			j = troca_estado(SEGUNDO_HORA, DECREMENTA_SEGUNDO, INCREMENTA_SEGUNDO);
			if ((hor[2] == 0) && (j == -1)){
				hor[2] = 59;
			}
			else if ((hor[2] == 59) && (j == 1)){
				hor[2] = 0;
			}
			else{
				hor[2] += j;
			}
			break;
	}
		
	SysTick_ativaInterrupt ();
	PORTA_ISFR |= 0x1030;
}

void ISR_carregaHorario(){
	RTClpo_getTime(&segundos);
	
	uint32_t s = segundos%86400;
	hor[0] = s/3600;
	hor[1] = (s/60)%60;
	hor[2] = s%60;
	hor[3] = segundos/86400;
}
