/*!
@file util.c
@brief Este m�dulo fun��es de utilidade geral
@author Rafael Cirino, Fernando Cillo
@date 27/04/2022
*/

#include "util.h"
#include "ISR.h"
#include "GPIO_ledRGB.h"
#include "GPIO_latch_lcd.h"



void atualizaHorarioLCD (uint32_t segundos, estado_type estado){
	char str_hhddss[8];
	ttoa(segundos, str_hhddss);

	char str_aux_h[3] = {str_hhddss[0], str_hhddss[1], '\0'};
	char str_aux_d[3] = {str_hhddss[3], str_hhddss[4], '\0'};
	char str_aux_s[3] = {str_hhddss[6], str_hhddss[7], '\0'};
	switch(estado){
		case NORMAL:
			GPIO_escreveStringLCD (0x04, str_hhddss);
			break;
		case DECREMENTA_HORA:
		case INCREMENTA_HORA:
			GPIO_escreveStringLCD (0x04, str_aux_h);
			break;
		case DECREMENTA_MINUTO:
		case INCREMENTA_MINUTO:
			GPIO_escreveStringLCD (0x07, str_aux_d);
			break;
		case DECREMENTA_SEGUNDO:
		case INCREMENTA_SEGUNDO:
			GPIO_escreveStringLCD (0x0A, str_aux_s);
			break;
	}

}

char *ttoa (uint32_t seconds, char* string)
{
	uint32_t dd, hh, mm, ss;

	s2dhms (seconds, &dd, &hh, &mm, &ss);
	
	string[2] = ':';
	string[5] = ':';    // inserir os espacadores
	string[8] = '\0';				// terminador

	if (hh > 23) {
		//!< horario invalido: FF:FF:FF
		string[0] = string[1] = string[3] = string[4] = string[6] = string[7] = 'F';
	}
	
	string[0] = (hh < 10)? '0': (hh/10)+'0';
	string[1] = hh%10+'0';
	
	string[3] = (mm < 10)? '0': (mm/10)+'0';
	string[4] = mm%10+'0';
	
	string[6] = (ss < 10)? '0': (ss/10)+'0';
	string[7] = ss%10+'0';	
	
	return string;
}

void s2dhms (uint32_t segundos, uint32_t *DD, uint32_t *HH, uint32_t *MM, uint32_t *SS)
{
	*DD = segundos/86400;

	uint32_t sec = segundos%86400;
	
	*SS = sec%60;
	
	*MM = (sec/60)%60;
	
	*HH = sec/3600;
	
}

void dhms2s (uint8_t DD, uint8_t HH, uint8_t MM, uint8_t SS, uint32_t *segundos)
{
	*segundos = DD*86400+HH*3600+MM*60+SS;
}

void ativa_cor(uint8_t e_cor){
	uint8_t x, y, z;
	booleano_type set[2] = {OFF, ON};	
	
	z = (e_cor & 0b001);
	y = ((e_cor & 0b010)>>1);
	x = ((e_cor & 0b100)>>2);
	
	GPIO_ledRGB(set[x], set[y], set[z]);
}

void delay_10us(unsigned int i)
{
	__asm__(								  
		"mov  r3, #0\n"					      
		"iteracao:\n"
			"mov	r2, #26\n"			  
		"laco:\n" 
			"add	r3, #0\n"     
			"sub	r3, #0\n"
			"add	r3, #0\n"     
			"sub	r3, #0\n"
			"add	r3, #0\n"    
			"sub 	r2, #1\n"					  
											  
			"bne 	laco\n"				  
											  
			"sub	r0, #1\n"
			"bne	iteracao\n"
		);
}
