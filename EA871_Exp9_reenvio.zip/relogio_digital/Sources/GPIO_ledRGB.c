/*!
* @file GPIO_ledRGB.c
* @brief Este m�dulo cont�m interface aos registradores do led
* RGB operando no modo GPIO.
* @author Rafael Cirino, Fernando Cillo
* @date 19/04/22
*/

#include "derivative.h"
#include "GPIO_ledRGB.h"
#include "util.h"

void GPIO_initLedR(){
	// Modulo SIM: habilita o clock do modulo PORTn
	SIM_SCGC5 |= SIM_SCGC5_PORTB_MASK;
	
	// Modulo PORT: configure o pino PTB18 para GPIO (vermelho)
	PORTB_PCR18 |= PORT_PCR_MUX (0b001); // mascarar os bits 8, 9 e 10
	
	// Modulo GPIO: configure o sentido do sinal (saida) nos pinos
	// PTB18
	GPIOB_PDDR |= GPIO_PDDR_PDD (0b1<<18);
	
	// Modulo GPIO: inicializar os pinos em 1 (ativo baixo)
	GPIOB_PSOR = GPIO_PSOR_PTSO (0b1<<18);
} 
void GPIO_initLedG(){
	// Modulo SIM: habilita o clock do modulo PORTn
	SIM_SCGC5 |= SIM_SCGC5_PORTB_MASK;
	
	// Modulo PORT: configure o pino PTB19 para GPIO (verde)
	PORTB_PCR19 |= PORT_PCR_MUX (0b001); // mascarar os bits 8, 9 e 10
	
	// Modulo GPIO: configure o sentido do sinal (saida) nos pinos
	// PTB19
	GPIOB_PDDR |= GPIO_PDDR_PDD (0b1<<19);
	
	// Modulo GPIO: inicializar os pinos em 1 (ativo baixo)
	GPIOB_PSOR = GPIO_PSOR_PTSO (0b1<<19);
	
} 
void GPIO_initLedB(){
	// Modulo SIM: habilita o clock do modulo PORTn
	SIM_SCGC5 |= SIM_SCGC5_PORTD_MASK;
	
	// Modulo PORT: configure o pino PTD1 para GPIO (azul)
	PORTD_PCR1 |= PORT_PCR_MUX (0b001); // mascarar os bits 8, 9 e 10
	
	// Modulo GPIO: configure o sentido do sinal (saida) nos pinos
	// PTD1
	GPIOD_PDDR |= GPIO_PDDR_PDD (0b1 << 1);
	
	// Modulo GPIO: inicializar os pinos em 1 (ativo baixo)
	GPIOD_PSOR = GPIO_PSOR_PTSO (0b1<<1);
}

void GPIO_desabilitaLedR(){
	PORTB_PCR18 &= ~PORT_PCR_MUX (0b111);
}
void GPIO_desabilitaLedG(){
	PORTB_PCR19 &= ~PORT_PCR_MUX (0b111);
}
void GPIO_desabilitaLedB(){
	PORTD_PCR1 &= ~PORT_PCR_MUX (0b111); // mascarar os bits 8, 9 e 10
}

void GPIO_ledR(booleano_type estado){
	if (estado == ON){
		GPIOB_PCOR = GPIO_PCOR_PTCO (0b1<<18);
	} else if(estado == OFF){
		GPIOB_PSOR = GPIO_PSOR_PTSO (0b1<<18);
	}
}
void GPIO_ledG(booleano_type estado){
	if (estado == ON){
		GPIOB_PCOR = GPIO_PCOR_PTCO (0b1<<19);
	} else if(estado == OFF){
		GPIOB_PSOR = GPIO_PSOR_PTSO (0b1<<19);
	}
}
void GPIO_ledB(booleano_type estado){
	if (estado == ON){
		GPIOD_PCOR = GPIO_PCOR_PTCO (0b1<<1);
	} else if(estado == OFF){
		GPIOD_PSOR = GPIO_PSOR_PTSO (0b1<<1);
	}
}

void GPIO_ledRGB(booleano_type estadoR, booleano_type estadoG, booleano_type estadoB){
	GPIO_ledR(estadoR);
	GPIO_ledG(estadoG);
	GPIO_ledB(estadoB);
	
}

void init_pte20(){
	SIM_SCGC5 |= SIM_SCGC5_PORTE_MASK;
	
	// Modulo PORT: configure o pino PTE20
	PORTE_PCR20 |= PORT_PCR_MUX (0b001); // mascarar os bits 8, 9 e 10
	
	// PTE20
	GPIOE_PDDR |= GPIO_PDDR_PDD (0b1<<20);
	
	GPIOE_PSOR = GPIO_PSOR_PTSO (0b1<<20);
}

void GPIO_pte20(booleano_type estado){
	if (estado == OFF){
		GPIOE_PCOR = GPIO_PCOR_PTCO (0b1<<20);
	} else if(estado == ON){
		GPIOE_PSOR = GPIO_PSOR_PTSO (0b1<<20);
	}
}

void GPIO_initLedRGB() {
	// Modulo SIM: habilita o clock do modulo PORTn
	SIM_SCGC5 |= (SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTD_MASK);
	
	// Modulo PORT: configure o pino PTB18 para GPIO (vermelho)
	PORTB_PCR18 |= PORT_PCR_MUX (0b001); // mascarar os bits 8, 9 e 10
	
	// Modulo PORT: configure o pino PTB19 para GPIO (verde)
	PORTB_PCR19 |= PORT_PCR_MUX (0b001); // mascarar os bits 8, 9 e 10
	
	// Modulo PORT: configure o pino PTD1 para GPIO (azul)
	PORTD_PCR1 |= PORT_PCR_MUX (0b001); // mascarar os bits 8, 9 e 10
	
	// Modulo GPIO: configure o sentido do sinal (saida) nos pinos
	// PTB18, PTB19 e PTD1
	GPIOB_PDDR |= GPIO_PDDR_PDD (0b11<<18);
	GPIOD_PDDR |= GPIO_PDDR_PDD (0b1 << 1);
	
	// Modulo GPIO: inicializar os pinos em 1 (ativo baixo)
	GPIOB_PSOR = GPIO_PSOR_PTSO (0b11<<18);
	GPIOD_PSOR = GPIO_PSOR_PTSO (0b1<<1);
}
