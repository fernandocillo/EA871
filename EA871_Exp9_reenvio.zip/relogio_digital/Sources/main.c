/*!
@file main.c
@brief Cont�m a main do experimento 9
@author Rafael Cirino, Fernando Cillo
@date 20/05/2022
*/

#include "GPIO_latch_lcd.h"
#include "GPIO_switches.h"
#include "ISR.h"
#include "timers.h"
#include "util.h"

void init_modules(){
	GPIO_ativaConLatchLCD ();
	GPIO_initLCD ();
	
	GPIO_initSwitches();
	GPIO_habilitaSwitchesInterrupt(3);
	
	RTClpo_init();
}

int main(void){
	init_modules();
	
	SysTick_init(10485760);
	
	uint32_t segundos_anterior, segundos_atual;
	
	static estado_type estado = NORMAL;
	RTClpo_setTime (0);
	ISR_carregaHorario();
	
	segundos_atual = 0;
	atualizaHorarioLCD (segundos_atual, estado);
	segundos_anterior = segundos_atual;
	
	GPIO_ativaCursorPiscanteLCD();
	
	for(;;){
		estado = ISR_LeEstado();
		switch (estado) {
			case NORMAL:
				RTClpo_getTime(&segundos_anterior);
				atualizaHorarioLCD (segundos_anterior, estado);
				break;
			case NORMAL_HORA:
				GPIO_ativaCursorPiscanteLCD();
				
				GPIO_setRS (COMANDO);
				GPIO_escreveByteLCD(0b10000000 | 0x04 , 4);
				
				ISR_EscreveEstado(HORA);
				break;
			case HORA:
				break;
			case INCREMENTA_HORA:
			case DECREMENTA_HORA:
				ISR_LeHorario(&segundos_atual);
				if (segundos_atual != segundos_anterior){
					atualizaHorarioLCD (segundos_atual, estado);
					segundos_anterior = segundos_atual;
				}
				break;
			case HORA_MINUTO:
				GPIO_setRS (COMANDO);
				GPIO_escreveByteLCD(0b10000000 | 0x07 , 4);
				
				ISR_EscreveEstado(MINUTO);
				break;
			case MINUTO:
				break;
			case INCREMENTA_MINUTO:
			case DECREMENTA_MINUTO:
				ISR_LeHorario(&segundos_atual);
				if (segundos_atual != segundos_anterior){
					atualizaHorarioLCD (segundos_atual, estado);
					segundos_anterior = segundos_atual;
				}
				break;
			case MINUTO_SEGUNDO:
				GPIO_setRS (COMANDO);
				GPIO_escreveByteLCD(0b10000000 | 0x0A , 4);
				
				ISR_EscreveEstado(SEGUNDO);
				break;
			case SEGUNDO:
				break;
			case INCREMENTA_SEGUNDO:
			case DECREMENTA_SEGUNDO:
				ISR_LeHorario(&segundos_atual);
				if (segundos_atual != segundos_anterior){
					atualizaHorarioLCD (segundos_atual, estado);
					segundos_anterior = segundos_atual;
				}
				break;
			case SEGUNDO_HORA:
				GPIO_setRS (COMANDO);
				GPIO_escreveByteLCD(0b10000000 | 0x04 , 4);
				
				ISR_EscreveEstado(HORA);
				break;
			}
	}
	
	return 0;
}
