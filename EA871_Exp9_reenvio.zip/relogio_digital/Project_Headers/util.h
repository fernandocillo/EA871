/*!
@file util.h
@brief Este m�dulo fun��es de utilidade geral
@author Rafael Cirino, Fernando Cillo
@date 27/04/2022
*/

#ifndef UTIL_H_
#define UTIL_H_

#include "stdint.h"
#include "ISR.h"

/*!
 * @brief Atualiza seconds no LCD confome estado informado
 * @param[in] segundos
 * @param[in] estado
 */
void atualizaHorarioLCD (uint32_t segundos, estado_type estado);

/*!
 * @brief Converte segundos para formato (DIA:)HH:MM:SS
 * @param[in] seconds segundos
 * @param[out] string horario no formato HH:MM:SS
 */
char *ttoa (uint32_t seconds, char *string);

/*!
 * @brief Converte segundos para unidades de tempo, dias, horas, minutos e segundos
 * @param[in] segundos: horario em segundos
 * @param[out] DD: dias
 * @param[out] HH: horas
 * @param[out] MM: minutos
 * @param[out] SS: segundos
 */
void s2dhms (uint32_t segundos, uint32_t *DD, uint32_t *HH, uint32_t *MM, uint32_t *SS);


/*!
 * @brief Converte hor�rio em unidades de tempo, dias, horas, minutos e segundos, para segundos
 * @param[in] DD: dias
 * @param[in] HH: horas
 * @param[in] MM: minutos
 * @param[in] SS: segundos
 * @param[out] segundos: horario eem segundos
 */
void dhms2s (uint8_t DD, uint8_t HH, uint8_t MM, uint8_t SS, uint32_t *segundos);


/*!
 * @brief Ativa a cor do led conforme a m�quina de estados
 * param[in] C�digo de cor no seguinte formato bin�rio: 0bRGB  
*/
void ativa_cor(uint8_t e_cor);

/*!
 * @brief Fun��o que shifta 1 por um determinado n�mero x de casass  
*/
#define GPIO_PIN(x) ((1)<<(x))

/*!
 * @brief Define um novo tipo de variavel chamada booleano_type
 * param[out] ON/OFF 
*/
typedef enum boolean_tag {
	OFF,
	ON
} booleano_type;

/*!
	* @brief A partir do argumento i mant�m o ultimo estado definido no c�digo por um per�odo de tempo\n
	* param[in] i:\n
	* i = 1: 10^-6s\n
	* i = 1000: 10^-3s\n
	* i = 10000: 0.1s\n
	* i = 50000: 0.5s\n
	* i = 100000: 1s
*/
void delay_10us(unsigned int i);

#endif /* UTIL_H_ */
