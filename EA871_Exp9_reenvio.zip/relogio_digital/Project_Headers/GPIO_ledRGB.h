/*!
* @file GPIO_ledRGB.h
* @brief Este m�dulo cont�m interface aos registradores do led
* RGB operando no modo GPIO.
* @author Rafael Cirino, Fernando Cillo
* @date 19/04/22
*/

#ifndef GPIO_LEDRGB_H_
#define GPIO_LEDRGB_H_

#include "util.h"

/*!
 * @brief Inicializa todas as sa�das necess�rias para acionar a porta PTB18, deixando o pino final em ativo baixo 1
*/
void GPIO_initLedR();

/*!
 * @brief Inicializa todas as sa�das necess�rias para acionar a porta PTB19, deixando o pino final em ativo baixo 1
*/
void GPIO_initLedG();

/*!
 * @brief Inicializa todas as sa�das necess�rias para acionar a porta PTD1, deixando o pino final em ativo baixo 1
*/
void GPIO_initLedB();

/*!
 * @brief A partir do argumento estado do tipo estado type, aciona (ON) ou n�o (OFF) o led vermelho
 * param[in] estado ON/OFF
*/
void GPIO_ledR(booleano_type estado);

/*!
 * @brief A partir do argumento estado do tipo estado type, aciona (ON) ou n�o (OFF) o led verde
 * param[in] estado ON/OFF
*/
void GPIO_ledG(booleano_type estado);

/*!
 * @brief A partir do argumento estado do tipo estado type, aciona (ON) ou n�o (OFF) o led azul
 * param[in] estado ON/OFF
*/
void GPIO_ledB(booleano_type estado);

/*!
 * @brief Aciona (ON) ou n�o (OFF) as sa�das do led RGB, a depender dos estados passados como argumento da fun��o
 * param[in] estadoR, estadoG, estadoB ON/OFF
*/
void GPIO_ledRGB(booleano_type estadoR, booleano_type estadoG, booleano_type estadoB);

/*!
 * @brief Desabilita a PTB18, led vermelho, n�o permitindo mais nenhum acionamento at� que ele seja inicializado novamente
 */
void GPIO_desabilitaLedR();

/*!
 * @brief Desabilita a PTB19, led verde, n�o permitindo mais nenhum acionamento at� que ele seja inicializado novamente
*/
void GPIO_desabilitaLedG();

/*!
 * @brief Desabilita a PTD1, led azul, n�o permitindo mais nenhum acionamento at� que ele seja inicializado novamente
 */
void GPIO_desabilitaLedB();

/*!
 * @brief Inicializa as sa�das requisitadas pelo usu�rio conforme especificado nos argumentos da fun��o
*/
void GPIO_initLedRGB();

/*!
 * @brief Inicializa todas as sa�das necess�rias para acionar a porta PTE20, deixando o pino final em ativo baixo 1
*/
void init_pte20();

/*!
 * @brief A partir do argumento estado do tipo estado type, aciona (ON) ou n�o (OFF) a sa�da da porta PTE20, muito �til para analises l�gicas, principalmente, tempo de execu��o.
 * param[in] estado ON/OFF
*/
void GPIO_pte20(booleano_type estado);


#endif /* GPIO_LEDRGB_H_ */

