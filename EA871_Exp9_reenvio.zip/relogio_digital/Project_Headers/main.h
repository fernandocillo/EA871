/*!
@file main.h
@brief Cont�m a main do experimento 9
@author Rafael Cirino, Fernando Cillo
@date 20/05/2022
*/

#ifndef MAIN_H_
#define MAIN_H_

/*!
 * @brief Inicializa os m�dulos necess�rios para o programa LCD, Switches, Led
*/
void init_modules();

/*!
 * @brief Programa que escreve no LCD o bitmap da paleta, e o nome da respectiva cor
 * @return 0
*/
int main (void);


#endif /* MAIN_H_ */
