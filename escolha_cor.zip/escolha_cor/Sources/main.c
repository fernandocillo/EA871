/*
 * main implementation: use this 'C' sample to create your own application
 *
 */

#include "derivative.h" /* include peripheral declarations */
#include "GPIO_switches.h"
#include "GPIO_ledRGB.h"
#include "util.h"


//associa uma vari�vel � lista de quais LEDs devem acender para determinada cor
void ativa_cor (int cor_estado){
	if (cor_estado==0b001){
		GPIO_ledRGB(OFF, OFF, ON);
	} else if (cor_estado==0b011){
			GPIO_ledRGB(OFF, ON, ON);
	} else if (cor_estado==0b101){
		GPIO_ledRGB(ON, OFF, ON);
	} else if (cor_estado==0b010){
		GPIO_ledRGB(OFF, ON, OFF);
	} else if (cor_estado==0b110){
		GPIO_ledRGB(ON, ON, OFF);
	} else if (cor_estado==0b100){
				GPIO_ledRGB(ON, OFF, OFF);
		}
}

//m�scara
void GPIO_amostraSwitches (int *valor){
	 *valor =((~GPIOA_PDIR & 0x1030)>> 4);
}

uint8_t amostra_switches (int estado, int NMI, int IRQA5, int IRQA12){
	int valor;
	uint8_t cor[9] = {0b001, 0b011, 0b101, 0b010, 0b011, 0b110, 0b100, 0b101, 0b110};
	
	//associa cada botoeira com um valor da vari�vel 'valor'
	GPIO_amostraSwitches (&valor);
			if (valor == 0x001) {
				estado=NMI;
			} else if (valor == 0x002) {
				estado=IRQA5;
			} else if (valor == 0x100) {
				estado=IRQA12;
			}
			
	ativa_cor(cor[estado]); //acende os LEDs correspondentes
	delay_10us(30000); //fun��o de atraso para execu��o correta dos comandos
	return estado; // 'salva' o valor do estado
}
	
//define as transi��es de estado e ativa os LEDs de acordo com o estado atual
int main (void)
{
	GPIO_initLedRGB();
	GPIO_initSwitches();
	
	uint8_t estado=0;
	
	for(;;) {
		switch (estado){
		case 0:
			estado = amostra_switches(estado, 1 ,3, 6);
		break;
		
		case 1:
			estado = amostra_switches(estado, 2, 4, 7);
		break;
		
		case 2:
			estado = amostra_switches(estado, 0, 5, 8);
		break;
		
		case 3:
			estado = amostra_switches(estado, 0, 4, 6);
		break;
		
		case 4:
			estado = amostra_switches(estado, 1, 5, 7);
		break;
		
		case 5:
			estado = amostra_switches(estado, 2, 3, 8);
		break;
		
		case 6:
			estado = amostra_switches(estado, 0, 3, 7);
		break;
		
		case 7:
			estado = amostra_switches(estado, 1, 4, 8);
		break;
		
		case 8:
			estado = amostra_switches(estado, 2, 5, 6);
		break;
		
		}
	}
	
return 0;
}

