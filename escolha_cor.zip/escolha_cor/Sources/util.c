/**
 * @file util.c
 * @brief Implementacao das funcoes utilitarias
 * @author Wu Shin Ting
 * @date 23/04/2022
 * 
 */
#include "util.h"

void delay (unsigned int i)
{
	while (i) i--;
}

/**
 * @brief atraso em numero de interacoes <i>
 * @param[in] i numero de iteracoes
 */
void delay_10us (unsigned int i) {
	
	__asm__ (								
			"mov  r3, #0\n\t"					      
			"iteracao:\n\t"
			
			"mov	r2, #26\n\t"			  
			"laco:\n\t" 
			"add		r3, #0\n\t"     
			"sub		r3, #0\n\t"
			"add		r3, #0\n\t"     
			"sub		r3, #0\n\t"
			"add		r3, #0\n\t"     
			"sub 		r2, #1\n\t"					  

			"bne 	laco\n\t"					  

			"sub	%0, #1\n\t"					  	  
			"bne	iteracao\n\t"

			:
			: "r" (i)			 //i recebe o codigo %0
			: "r2","r3" //os registradores usados no escopo __asm__
	);
}
