/*!
@file GPIO_switches.c
@brief   Este   m�dulo   cont�m   interface   aos   registradores   de
switches no modo GPIO
@author <seu nome>
@date <o dia em que voc� criou>
*/
#include "derivative.h" 
#include "util.h"

void GPIO_initBotoeiraNMI () {
	// Habilita o clock do modulo PORTA
	SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK;				// para botoeiras   					// para leds

	// Funcao GPIO
	PORTA_PCR4 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
	PORTA_PCR4 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001

	// Sentido do sinal: entrada (0x400ff014)
	GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(4)));    
}

void GPIO_initSwitches(){
// Habilita o clock do modulo PORTA
		SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK;				// para botoeiras   					// para leds

//NMI
		// Funcao GPIO
		PORTA_PCR4 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
		PORTA_PCR4 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001

		// Sentido do sinal: entrada (0x400ff014)
		GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(4))); 
		
//IRQ5
		// Funcao GPIO
		PORTA_PCR5 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
		PORTA_PCR5 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001

		// Sentido do sinal: entrada (0x400ff014)
		GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(5)));
				
//IRQ12
		// Funcao GPIO
		PORTA_PCR12 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
		PORTA_PCR12 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001

		// Sentido do sinal: entrada (0x400ff014)
		GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(12)));
}
