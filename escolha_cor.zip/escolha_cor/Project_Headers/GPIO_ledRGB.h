/**
 * @file GPIO_ledRGB.h
 * @brief Funcoes relacionadas com o controle do ledRGB via GPIO
 * @author Wu Shin TIng
 * @date 23/04/2022
 */

#ifndef GPIO_LEDRGB_H_
#define GPIO_LEDRGB_H_

//Declaracao de macros definidas para os registradores do microcontrolador
#include "derivative.h"
//Declaracao de macros e funcoes do arquivo util.h
#include "util.h"

/**
 * @brief inicializa o componente ledRGB
 */
void GPIO_initLedRGB();

/**
 * @brief inicilizar os pinos de controle de R e G do led RGB, conectadas nos pinos
 * PTB18, PTB19 e PTD1
 */
void GPIO_initLedRG();

/**
 * @brief inicilizar os pinos de controle de G e B do led RGB, conectadas nos pinos
 * PTB19 e PTD1
 */
void GPIO_initLedGB();

/**
 * @brief inicilizar os pinos de controle de B e R do led RGB, conectadas nos pinos
 * PTB18 e PTD1
 */
void GPIO_initLedBR();

/**
 * @brief inicializa o led vermelho do ledRGB
 */
void GPIO_initLedR();

/**
 * @brief inicializa led verde do ledRGB
 */
void GPIO_initLedG();

/**
 * @brief inicializa led azul do led RGB
 */
void GPIO_initLedB();

/**
 * @brief seta o estado do led vermelho do componente ledRGB
 * @param[in] estado ON/OFF
 */
void GPIO_ledR(booleano_type estado);

/**
 * @brief seta o estado do led verde do componente ledRGB
 * @param[in] estado ON/OFF
 */
void GPIO_ledG(booleano_type estado);

/**
 * @brief seta o estado do led azul do componente ledRGB
 * @param[in] estado ON/OFF
 */
void GPIO_ledB(booleano_type estado);

/**
 * @brief seta o estado dos leds vermelho e verde do componente ledRGB
 * @param[in] estado ON/OFF
 */
void GPIO_ledRG(booleano_type estado);

/**
 * @brief seta o estado dos leds verde e azul do componente ledRGB
 * @param[in] estado ON/OFF
 */
void GPIO_ledGB(booleano_type estado);

/**
 * @brief seta o estado dos leds azul e vermelho do componente ledRGB
 * @param[in] estado ON/OFF
 */
void GPIO_ledBR(booleano_type estado);

/**
 * @brief seta o estado do componente ledRGB
 * @param[in] estadoR ON/OFF led R
 * @param[in] estadoG ON/OFF led G
 * @param[in] estadoB ON/OFF led B
 */
void GPIO_ledRGB(booleano_type estadoR, booleano_type estadoG, booleano_type estadoB);

/**
 * @brief Alterna o estado do led R
 */
void GPIO_ledR_t();

/**
 * @brief Alterna o estado do led G
 */
void GPIO_ledG_t();

/**
 * @brief Alterna o estado do led B
 */
void GPIO_ledB_t();

/**
 * @brief Alterna o estado do led RG
 */
void GPIO_ledRG_t();

/**
 * @brief Alterna o estado do led GB
 */
void GPIO_ledGB_t();

/**
 * @brief Alterna o estado do led BR
 */
void GPIO_ledBR_t();

/**
 * @brief Alterna o estado do led RGB
 */
void GPIO_ledRGB_t();

#endif /* GPIO_LEDRGB_H_ */
