/*
 * GPIO_switches.h
 *
 *  Created on: May 2, 2022
 *      Author: ea871
 */

#ifndef GPIO_SWITCHES_H_
#define GPIO_SWITCHES_H_

void GPIO_initBotoeiraNMI ();

void GPIO_initSwitches();

#endif /* GPIO_SWITCHES_H_ */
