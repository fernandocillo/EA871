/*!
@file main.c
@brief main do experimento 8
@author Rafael Cirino, Fernando Cillo
@date 15/05/2022
*/

#include "derivative.h"
#include "GPIO_latch_lcd.h"
#include "GPIO_switches.h"
#include "GPIO_ledRGB.h"
#include "ISR.h"
#include "util.h"

void constroiBitmaps(uint8_t* end, uint8_t n, char** symbol){
	uint8_t i;
	for (i = 0; i < n; ++i){
		GPIO_escreveBitmapLCD (end[i], symbol[i]);
	}
}

void init_modules(){
	GPIO_ativaConLCD ();
	GPIO_initLCD ();
	
	GPIO_initLedRGB();
	
	GPIO_initSwitches();
	GPIO_habilitaSwitchesInterrupt(3);
}


 int main (void){
	init_modules();
	
	char cronometro[8] = {0x11, 0xe, 0x15, 0x15, 0x1d, 0x11, 0xe, 0x0};
	char relogio[8]= {0x0, 0xe, 0x15, 0x15, 0x17, 0x11, 0xe, 0x0};
	char termometro[8] = {0x4, 0xa, 0xa, 0xa, 0xe, 0x1f, 0x1f, 0xe};
	uint8_t ends[3]={0x02, 0x03, 0x04};
	char str_bitmaps[4] = {0x02, 0x03, 0x04, 0x00};
	char *bit_array[3] = {cronometro, relogio, termometro};
		
	constroiBitmaps (ends, 3, bit_array);
	
	uint8_t cor[9]={0b001, 0b011, 0b101, 0b010, 0b011, 0b110,
		0b100, 0b101, 0b110};
	char *cor_nome[] = {
		"AZUL    ",
		"CIANO   ",
		"MAGENTA ",
		"VERDE   ",
		"CIANO   ",
		"AMARELO ",
		"VERMELHO",
		"MAGENTA ",
		"AMARELO "};
	
	uint8_t estado_anterior = 0;
	uint8_t paleta_anterior = 0;
	uint8_t estado_corrente = 0;
	uint8_t paleta_corrente = 0;
	    
	for (;;){
		estado_corrente = ISR_LeEstado();
		if (estado_anterior != estado_corrente) {
			estado_anterior = estado_corrente;
			paleta_corrente = ISR_LePaleta();
			
			if (paleta_anterior != paleta_corrente) {
				paleta_anterior = paleta_corrente;
				}
		}
		
		ativa_cor(cor[estado_corrente]);
		char write_bitmap[2] = {str_bitmaps[paleta_corrente], 0x00};
		GPIO_escreveStringLCD (0xf, write_bitmap);
		GPIO_escreveStringLCD (0x40, cor_nome[estado_corrente]);
		
		delay_10us (100000);
	}
	
	return 0;
}
