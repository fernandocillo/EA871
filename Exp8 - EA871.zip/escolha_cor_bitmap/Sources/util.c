/*!
@file util.c
@brief Este m�dulo fun��es de utilidade geral
@author Rafael Cirino, Fernando Cillo
@date 27/04/2022
*/

#include "util.h"
#include "GPIO_ledRGB.h"

void ativa_cor(uint8_t e_cor){
	uint8_t x, y, z;
	booleano_type set[2] = {OFF, ON};	
	
	z = (e_cor & 0b001);
	y = ((e_cor & 0b010)>>1);
	x = ((e_cor & 0b100)>>2);
	
	GPIO_ledRGB(set[x], set[y], set[z]);
}

void delay_10us(unsigned int i)
{
	__asm__(								  
		"mov  r3, #0\n"					      
		"iteracao:\n"
			"mov	r2, #26\n"			  
		"laco:\n" 
			"add	r3, #0\n"     
			"sub	r3, #0\n"
			"add	r3, #0\n"     
			"sub	r3, #0\n"
			"add	r3, #0\n"    
			"sub 	r2, #1\n"					  
											  
			"bne 	laco\n"				  
											  
			"sub	r0, #1\n"
			"bne	iteracao\n"
		);
}
