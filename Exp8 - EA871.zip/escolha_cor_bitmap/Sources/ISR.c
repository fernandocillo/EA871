/*!
@file ISR.c
@brief O m�dulo cont�m fun��es de interrup��o
@author Rafael Cirino, Fernando Cillo
@date 15/05/2022
*/

#include "util.h"
#include "derivative.h"
#include "GPIO_switches.h"

static uint8_t estado = 0;
static uint8_t paleta = 0;


uint8_t ISR_LeEstado ()
{
	return estado;
}

uint8_t ISR_LePaleta ()
{
	return paleta;
}

void troca_estado(uint8_t e_nmi, uint8_t e_i5, uint8_t e_i12){
	uint8_t cor[9]={0b001, 0b011, 0b101, 0b010, 0b011, 0b110, 0b100, 0b101, 0b110};
	uint8_t array_paleta[3]={0, 1, 2};
	int valor;
	
	GPIO_leSwitchesISF(&valor);
	
	if (valor == 0x1) {
		estado = e_nmi;
	} else if (valor == 0x2) {
		estado = e_i5;
	} else if (valor == 0x100) {
		estado = e_i12;
	}
	
	paleta = estado/3;
	//ativa_cor(cor[estado]);
	
}

void PORTA_IRQHandler (void)
{	
	switch (estado){
			case 0: //[0,0]
				troca_estado(1, 3, 6);
			break;
			
			case 1: //[0,1]
				troca_estado(2, 4, 7);
			break;
			
			case 2: //[0,2]
				troca_estado(0, 5, 8);
			break;
			
			case 3: //[1,0]
				troca_estado(0, 4, 6);
			break;
			
			case 4: //[1,1]
				troca_estado(1, 5, 7);
			break;
			
			case 5: //[1,2]
				troca_estado(2, 3, 8);
			break;
			
			case 6: //[2,0]
				troca_estado(0, 3, 7);
			break;
			
			case 7: //[2,1]
				troca_estado(1, 4, 8);
			break;
			
			case 8: //[2,2]
				troca_estado(2, 5, 6);
			break;
			
		}
}

