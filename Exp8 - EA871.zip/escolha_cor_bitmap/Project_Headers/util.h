/*
 * util.h
 *
 *  Created on: Apr 27, 2022
 *      Author: rafac
 */

#ifndef UTIL_H_
#define UTIL_H_

#include "derivative.h"

/*!
 * @brief Ativa a cor do led conforme a m�quina de estados
 * param[in] C�digo de cor no seguinte formato bin�rio: 0bRGB  
*/
void ativa_cor(uint8_t e_cor);

/*!
 * @brief Fun��o que shifta 1 por um determinado n�mero x de casass  
*/
#define GPIO_PIN(x) ((1)<<(x))

/*!
 * @brief Define um novo tipo de variavel chamada booleano_type
 * param[out] ON/OFF 
*/
typedef enum boolean_tag {
	OFF,
	ON
} booleano_type;

/*!
	* @brief A partir do argumento i mant�m o ultimo estado definido no c�digo por um per�odo de tempo\n
	* param[in] i:\n
	* i = 1: 10^-6s\n
	* i = 1000: 10^-3s\n
	* i = 10000: 0.1s\n
	* i = 50000: 0.5s\n
	* i = 100000: 1s
*/
void delay_10us(unsigned int i);

#endif /* UTIL_H_ */
