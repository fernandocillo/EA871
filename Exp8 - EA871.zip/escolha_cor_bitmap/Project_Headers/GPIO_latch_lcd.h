/*
 * @file 
 * @brief Prototipos do modulo GPIO_latch_lcd
 * @author Wu Shin Ting
 * @date 28/02/2022
 */

#ifndef GPIO_LATCH_LCD_H_
#define GPIO_LATCH_LCD_H_
#include "stdint.h"

/**
 * @brief Funcao do byte enviado para LCD
 */
typedef enum lcd_RS_tag {
	COMANDO,  //!< Comando (0) 
	DADO	  //!< Dado (1) 
} lcd_RS_type;

//===========================================================
// Latch e LCD
//===========================================================
/*!
 * @brief Ativa conexao entre mcu com latch e lcd
 */
void GPIO_ativaConLatchLCD ();

/*!
 * @brief Envia um mesmo byte para latch (ativando LE) e LCD (ativando Enable) 
 * @param[in] c byte
 * @param[in] t tempo de processamento em multiplos de 5us
 */
void GPIO_escreveByteLatchLCD(char c, uint8_t t);

/*!
 * @brief Envia um byte para latch
 * @param[in] c byte
 */
void GPIO_escreveByteLatch(char c);

/*!
 * @brief Ativa as entradas do LCD
 */
void GPIO_ativaConLCD ();

/*!
 * @brief Seta o tipo de acesso ao LCD 
 * @param[in] i: COMANDO ou DADO
 */
void GPIO_setRS (lcd_RS_type i);

/*!
 * @brief Envia um byte para LCD
 * @param[in] c: byte
 * @param[in] t: delay
 */
void GPIO_escreveByteLCD(char c, uint32_t t);

/*!
 * @brief Inicializa o LCD, escrevendo e apagando textos nele
 */
void GPIO_initLCD ();

/*!
 * @brief Escreve um bitmap no lcd e armazena na mem�ria CGROM
 * @param[in] end: endere�os da CGROM
 * @param[in] bitmap: array do bitmap em hex
 */
void GPIO_escreveBitmapLCD (uint8_t end, char* bitmap);

/*!
 * @brief Escreve um texto no lcd e armazena na mem�ria CGROM
 * @param[in] end: endere�os da CGROM
 * @param[in] str: texto a ser escrito
 */
void GPIO_escreveStringLCD (uint8_t end, char* str);

/*!
 * @brief Apaga o que estava anteriormente escrito no LCD
 */
void GPIO_limpaDisplayLCD ();

/*!
 * @brief Seta end no registrador de endereco (cursor) de DDRAM
 * @param[in] end endereco da memoria DDRAM
 * 
 * @note Consulta os enderecos de cada celula das duas linhas na 
 * @note secao 11 em ftp://ftp.dca.fee.unicamp.br/pub/docs/ea079/datasheet/AC162A.pdf
 */
void GPIO_setEndDDRAMLCD (uint8_t end);

#endif /* GPIO_LATCH_LCD_H_ */
