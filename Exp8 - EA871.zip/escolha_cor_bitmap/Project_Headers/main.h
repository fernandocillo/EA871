/*
 * main.h
 *
 *  Created on: May 16, 2022
 *      Author: rafac, ferC
 */

#ifndef MAIN_H_
#define MAIN_H_

/*!
 * @brief Armazena o bitmap gerado na mem�ria do LCD 
 * @param[in] end: vetor contendo os endere�os de mem�ria
 * @param[in] symbol: vetor com os endere�os dos bitmaps
*/
void constroiBitmaps(uint8_t end[], char* symbol[]);

/*!
 * @brief Inicializa os m�dulos necess�rios para o programa LCD, Switches, Led
*/
void init_modules();

/*!
 * @brief Programa que escreve no LCD o bitmap da paleta, e o nome da respectiva cor
*/
int main (void);


#endif /* MAIN_H_ */
