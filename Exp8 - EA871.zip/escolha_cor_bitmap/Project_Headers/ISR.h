/*
 * ISR.h
 *
 *  Created on: May 6, 2022
 *      Author: rafac, ferC
 */

#ifndef ISR_H_
#define ISR_H_

#include "util.h"

/*!
 * @brief Retorna a vari�vel paleta, tornando ela global 
*/
uint8_t ISR_LePaleta ();

/*!
 * @brief Retorna a vari�vel estado, tornando ela global 
*/
uint8_t ISR_LeEstado();

/*!
 * @brief Alterna entre os estados da m�quina de estado 
 * @param[in] e_nmi: estado ao se precionar o bot�o nmi
 * @param[in] e_i5: estado ao se precionar o bot�o irqa5
 * @param[in] e_i12: estado ao se precionar o bot�o irqa12
*/
void troca_estado(uint8_t e_nmi, uint8_t e_i5, uint8_t e_i12);


#endif /* ISR_H_ */
