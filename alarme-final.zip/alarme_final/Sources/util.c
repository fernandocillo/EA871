/*!
@file util.c
@brief Este m�dulo fun��es de utilidade geral
@author Rafael Cirino, Fernando Cillo
@date 27/04/2022
*/

#include "util.h"
#include "ISR.h"
#include "GPIO_latch_lcd.h"
#include "stdlib.h"
#include "string.h"
#include "math.h"
#include "ctype.h"

int str_time (char string[], int *seg){
	char* str;
	const char espaco[1] = " ";

	int i = 0;
	int oper_i[3];
	
	for(str=strtok(string, espaco); str!=0; str=strtok(0, espaco)){
	      if(isdigit(*str) != 0){
	          oper_i[i] = atoi(str);
	      } else if (i > 2){
	          return -1;
	      } else{
	          return -1;
	      }
	  
	  i += 1;
	}
	
	dhms2s(0, oper_i[0], oper_i[1], oper_i[2], seg);
	
	if (i < 3){
	  return -1;
	}
	
	return 0;
}


void atualizaHorarioLCD (uint32_t segundos, estado_type estado){
	char str_hhddss[8];
	ttoa(segundos, str_hhddss);
	
	switch(estado){
		case CONFIG_ALARME:
		case HORA_LCD:
		case INICIO:
			GPIO_escreveStringLCD (0x04, str_hhddss);
			break;
		case VERIFICA_ALARME:
			GPIO_escreveStringLCD (0x44, str_hhddss);
			
	}

}

char *ttoa (uint32_t seconds, char* string)
{
	uint32_t dd, hh, mm, ss;

	s2dhms (seconds, &dd, &hh, &mm, &ss);
	
	string[2] = ':';
	string[5] = ':';    // inserir os espacadores
	string[8] = '\0';				// terminador

	if (hh > 23) {
		//!< horario invalido: FF:FF:FF
		string[0] = string[1] = string[3] = string[4] = string[6] = string[7] = 'F';
	}
	
	string[0] = (hh < 10)? '0': (hh/10)+'0';
	string[1] = hh%10+'0';
	
	string[3] = (mm < 10)? '0': (mm/10)+'0';
	string[4] = mm%10+'0';
	
	string[6] = (ss < 10)? '0': (ss/10)+'0';
	string[7] = ss%10+'0';	
	
	return string;
}

void s2dhms (uint32_t segundos, uint32_t *DD, uint32_t *HH, uint32_t *MM, uint32_t *SS)
{
	*DD = segundos/86400;

	uint32_t sec = segundos%86400;
	
	*SS = sec%60;
	
	*MM = (sec/60)%60;
	
	*HH = sec/3600;
	
}

void dhms2s (uint8_t DD, uint8_t HH, uint8_t MM, uint8_t SS, uint32_t *segundos)
{
	*segundos = DD*86400+HH*3600+MM*60+SS;
}

void delay_10us(unsigned int i)
{
	__asm__(								  
		"mov  r3, #0\n"					      
		"iteracao:\n"
			"mov	r2, #26\n"			  
		"laco:\n" 
			"add	r3, #0\n"     
			"sub	r3, #0\n"
			"add	r3, #0\n"     
			"sub	r3, #0\n"
			"add	r3, #0\n"    
			"sub 	r2, #1\n"					  
											  
			"bne 	laco\n"				  
											  
			"sub	r0, #1\n"
			"bne	iteracao\n"
		);
}
