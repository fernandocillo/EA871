/*!
@file main.c
@brief Cont�m a main do projeto final
@author Rafael Cirino, Fernando Cillo
@date 10/07/2022
*/

#include "GPIO_latch_lcd.h"
#include "GPIO_switches.h"
#include "ISR.h"
#include "ISR_uart.h"
#include "timers.h"
#include "util.h"
#include "main.h"
#include "TPM.h"
#include "GPIO_ledRGB.h"


uint32_t segundos_anterior, segundos_atual, segundos_alarme;
estado_type estado;

void config_uart(){
	/*!
	 * Seta o divisor de frequencia do barramento
	 */
	SIM_setaOUTDIV4 (0b001);
	
	/*!
	 * Configurar UART0 com Rx e Tx habilitados: SBR tem que ser aproximado para maior que baud rate setado
	 */
	config0.sbr = (uint16_t)(20971520./(BAUD_RATE * (config0.c4_osr+1)));
	if ((20971520./(1.0 * BAUD_RATE * (config0.c4_osr+1))) > config0.sbr)
		config0.sbr++;
	UART0_initTerminal (&config0);

	/*!
	 * Ativa IRQs
	 */
	UART0_ativaIRQTerminal (0);

	// Setup
	ISR_inicializaBC();
	
	/*!
	 * Habilita a interrupcao do Rx do UART0
	 */
	UART0_ativaInterruptRxTerminal();
	//UART0_ativaInterruptTxTerminal();
	
	ISR_EnviaString ("\n\r");
}

void init_modules(){
	GPIO_ativaConLatchLCD ();
	GPIO_initLCD ();
	GPIO_initLedRGB();
	
	GPIO_initSwitches();
	GPIO_habilitaSwitchesInterrupt(3);
	
	RTClpo_init();
	//RTC_ativaSegundoIRQ (2);
	RTC_AlarmIRQ(1);
	
	SysTick_init(10485760);
}

int config_hora(){
	uint32_t segundos;
	
	estado = ISR_LeEstado();
	char s_entrada[8];
	
	if (estado == HORA_ATUAL){
		ISR_EnviaString("Digite a hora atual no seguinte formato: 00 00 00 \n\r");
	} else if (estado == CONFIG_ALARME){
		GPIO_escreveStringLCD (0x02, "Insira alarme");
		ISR_EnviaString("Digite o alarme no seguinte formato: 00 00 00 \n\r");
	}
	
	
	estado = ISR_LeEstado();
	while ((estado == HORA_ATUAL) || (estado == CONFIG_ALARME)){
		estado = ISR_LeEstado();
		if (estado == HORA_LCD){
			ISR_extraiString(s_entrada);
			ISR_EnviaString("\n\r");
			
			str_time (s_entrada, &segundos);
			ISR_EscreveEstado (INICIO);
		}
	}
	
	return segundos;
}

int main(void){
	config_uart();
	init_modules();
	segundos_atual = config_hora();
	
	RTClpo_setTime (segundos_atual);
	ISR_carregaHorario();
	
	//segundos_atual = 0;
	atualizaHorarioLCD (segundos_atual, estado);
	segundos_anterior = segundos_atual;
	
	//ISR_EscreveEstado (INICIO);
	
	TPM_initPTB0EPWM(65525, 0b101, 0, ON);
	for(;;){
		estado = ISR_LeEstado();
		
		switch (estado) {
			case INICIO:
				RTClpo_getTime(&segundos_anterior);
				atualizaHorarioLCD (segundos_anterior, estado);
				
				TPM_atualizaDutyCycleEPWM(1, 0, 0);
				break;
			case CONFIG_ALARME:
				segundos_alarme = config_hora();
				GPIO_escreveStringLCD (0x01, "                  ");
				atualizaHorarioLCD (segundos_alarme, estado);
				
				RTC_ativaAlarmIRQ ();
				RTClpo_setAlarm (segundos_alarme);
				
				ISR_EscreveEstado (CONFIRMACAO);
				break;
			case VERIFICA_ALARME:
				GPIO_escreveStringLCD (0x02, "Alarme config");
				atualizaHorarioLCD (segundos_alarme, estado);
				
				ISR_EscreveEstado (ALARME_ATIVO);
				break;
			case LIMPA_ALARME:
				GPIO_escreveStringLCD (0x01, "                  ");
				GPIO_escreveStringLCD (0x42, "                ");
				
				ISR_EscreveEstado (INICIO);
				break;
			case ALARME_INTERRUPT:
				GPIO_escreveStringLCD (0x02, "ALARME ALARME");
				GPIO_ledRGB(ON, OFF, OFF);
				
				ISR_EscreveEstado (MENSAGEM);
				break;
			case MENSAGEM:
				TPM_atualizaDutyCycleEPWM(1, 0, 50);
				break;
			case ALARME_ATIVO:
			case CONFIRMACAO:
			case HORA_ATUAL:
				break;
		}
	}
	
	return 0;
}
