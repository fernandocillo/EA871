/*!
@file ISR.c
@brief O m�dulo cont�m fun��es de interrup��o
@author Rafael Cirino, Fernando Cillo
@date 15/05/2022
*/

#include "util.h"
#include "ISR.h"
#include "timers.h"
#include "TPM.h"
#include "derivative.h"
#include "GPIO_switches.h"
#include "GPIO_latch_lcd.h"
#include "GPIO_ledRGB.h"

	
static estado_type estado = HORA_ATUAL;
static uint32_t segundos;
static uint32_t seg_alarm = 0;
static uint32_t hor[4] = {0, 0, 0, 0};

static uint8_t contador;

static int valor;

estado_type ISR_LeEstado ()
{
	return estado;
}

void ISR_EscreveEstado (estado_type w_estado)
{
	estado = w_estado;
}

void ISR_EscreveSegundo (estado_type w_segundo)
{
	seg_alarm = w_segundo;
}

void ISR_LeHorario(uint32_t* segundos){
	dhms2s (hor[3], hor[0], hor[1], hor[2], segundos);
}

void SysTick_Handler(void){
	ISR_LeHorario(&segundos);
	
	if((contador > 8) && (estado == ALARME_ATIVO)){
		SysTick_desativaInterrupt ();
		
		contador = 0;
		ISR_EscreveEstado (LIMPA_ALARME);
	} else if ((contador > 8) && (estado == MENSAGEM)){
		SysTick_desativaInterrupt ();
		//TPM_atualizaDutyCycleEPWM(1, 0, 0);
		
		contador = 0;
		GPIO_ledRGB(OFF, OFF, OFF);
		ISR_EscreveEstado (LIMPA_ALARME);
	} else if ((contador > (seg_alarm * 2)) && (estado == INICIO)){
		SysTick_desativaInterrupt ();
		//TPM_atualizaDutyCycleEPWM(1, 0, 50);
		
		contador = 0;
		seg_alarm = 0;
		SysTick_ativaInterrupt ();
		ISR_EscreveEstado (ALARME_INTERRUPT);
		//RTC_desativaAlarmIRQ ();
		
		
	}
	contador++;
}

void RTC_Alarm_IRQHandler (void){
	if (estado == INICIO){
		RTC_desativaAlarmIRQ ();
		SysTick_ativaInterrupt ();
		//ISR_EscreveEstado (ALARME_INTERRUPT);
	}
}

void PORTA_IRQHandler (void){
	GPIO_leSwitchesISF(&valor);
	
	switch(estado){
		case INICIO:
			if (valor == 0x2) {
				ISR_EscreveEstado (CONFIG_ALARME);
			} else if (valor == 0x1) {
				SysTick_ativaInterrupt ();
				ISR_EscreveEstado (VERIFICA_ALARME);
			}
			break;
		case CONFIRMACAO:
			if (valor == 0x100) {
				ISR_EscreveEstado (LIMPA_ALARME);
			}
			break;
	}
		
	//SysTick_ativaInterrupt ();
	PORTA_ISFR |= 0x1030;
}

void ISR_carregaHorario(){
	RTClpo_getTime(&segundos);
	
	uint32_t s = segundos%86400;
	hor[0] = s/3600;
	hor[1] = (s/60)%60;
	hor[2] = s%60;
	hor[3] = segundos/86400;
}
