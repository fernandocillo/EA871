/*!
@file ISR.h
@brief O m�dulo cont�m fun��es de interrup��o
@author Rafael Cirino, Fernando Cillo
@date 15/05/2022
*/

#ifndef ISR_H_
#define ISR_H_

#include "util.h"

/*!
 * @brief Muda o valor da vari�vel segundo
 * @param[in] w_segundo: Novo segundo 
*/
void ISR_EscreveSegundo (estado_type w_segundo);

/*!
 * @brief Muda o valor da vari�vel estado
 * @param[in] w_estado: Novo estado 
*/
void ISR_EscreveEstado (estado_type w_estado);

/*!
 * @brief Carrega o hor�rio contido no registrador RTCl
*/
void ISR_carregaHorario();

/*!
 * @brief Retorna a vari�vel de tempo em segundos 
 * @param[in] segundos: Vari�vel onde ser� salvo o hor�rio atual em segundos
*/
void ISR_LeHorario(uint32_t* segundos);

/*!
 * @brief Retorna a vari�vel estado, tornando ela global 
 * @return estado atual
*/
uint8_t ISR_LeEstado();

/*!
 * @brief Alterna entre os estados da m�quina de estado 
 * @param[in] e_nmi: estado ao se precionar o bot�o nmi
 * @param[in] e_i5: estado ao se precionar o bot�o irqa5
 * @param[in] e_i12: estado ao se precionar o bot�o irqa12
 * @return ...
*/
int8_t troca_estado(uint8_t e_nmi, uint8_t e_i5, uint8_t e_i12);


#endif /* ISR_H_ */
