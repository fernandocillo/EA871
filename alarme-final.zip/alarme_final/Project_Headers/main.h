/*!
@file main.h
@brief Cont�m a main do experimento 11
@author Rafael Cirino, Fernando Cillo
@date 16/06/2022
*/

#include "UART.h"

#ifndef MAIN_H_
#define MAIN_H_

#define BAUD_RATE 38400

/*!
 * @brief Variavel de configuracao de UART0
 */
UART0Config_type config0 = {
//		.bdh_sbns=0,		///< Um stop bit
		.bdh_sbns=1,		///< Dois stop bits
		.sbr=0b100, 		///< MCGFLLCLK/(baud_rate*osr)=4
		.c1_loops=0,		///< Operacao normal: full-duplex 
		.c1_dozeen=0,		///< UART habilitado no modo WAIT
		.c1_rsrc=0,			///< nao tem efeito para loops == 0
		.c1_m=0,			///< dados em 8 bits
		.c1_wake=0,			///< wakeup de RX por linha ociosa (IDLE)
		.c1_ilt=0,			///< deteccao do estado ocioso pela contagem apos start bits
		.c1_pe=0,			///< sem checagem de paridade por hardware
		.c1_pt=0,			///< bit de paridade par (sem efeito se pe==0)
		.c2_rwu=0,			///< operacao normal de recepcao do UART0
		.c2_sbk=0,			///< operacao normal de transmissor do UART0
		.s2_msbf=0,			///< envio de MSB para LSB
		.s2_rxinv=0,		///< polaridade dos dados de RX nao eh invertida
		.s2_rwuid=0,		///< nao tem efeito para rwu==0
		.s2_brk13=0,		///< nao tem efeito para operacao normal de transmissor
		.s2_lbkde=0,		///< deteccao do caractere break no tamanho menor
		.c3_r8t9=0,			///< nao tem efeito para m==0
		.c3_r9t8=0,			///< nao tem efeito para m==0
		.c3_txdir=0,		///< nao tem efeito para loops==0
		.c3_txinv=0,		///< polaridade dos dados de TX nao eh invertida 
		.c4_maen1=0,		///< todos os dados recebidos sao transferidos para buffer de dados
		.c4_maen2=0,			
		.c4_m10=0,			///< tamanho dos dados em RX e TX � 8 ou 9 bits
		.c4_osr=0b01111,	///< superamostragem 16x
		.c5_tdmae=0,		///< uso de DMA pelo TX desabilitada
		.c5_rdmae=0,		///< uso de DMA pelo RX desabilitado
		.c5_bothedge=0,		///< amostragem somente na borda de subida do clock
		.c5_resyncdis=0		///< resincronizacao na recepcao habilitada
};

/*!
 * @brief Configura a inicializa��o do m�dulo UART
 */
void config_uart();

/*!
 * @brief Programa do roteiro 11
 */
int main();

#endif /* MAIN_H_ */
