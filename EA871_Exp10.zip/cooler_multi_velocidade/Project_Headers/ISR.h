/*!
@file ISR.h
@brief O m�dulo cont�m fun��es de interrup��o
@author Rafael Cirino, Fernando Cillo
@date 15/05/2022
*/

#ifndef ISR_H_
#define ISR_H_

#include "util.h"

typedef enum estado_tag {DESLIGADO, RESET, DECREMENTA, INCREMENTA} estado_type;

/*!
 * @brief Retorna o estado atual
 * @return estado
 */
estado_type ISR_LeEstado ();

/*!
 * @brief Retorna o valor da porcentagem atual
 * @return porcentagem
 */
uint8_t ISR_LePercentagem ();

/*!
 * @brief Alterna entre os estados da m�quina de estado 
 * @param[in] e_nmi: estado ao se precionar o bot�o nmi
 * @param[in] e_i5: estado ao se precionar o bot�o irqa5
 * @param[in] e_i12: estado ao se precionar o bot�o irqa12
 * @param[in] i12_i5: estado ao se precionar o bot�o irqa15 + irqa12
 * @return j: incremento da porcentagem
*/
int8_t troca_estado(estado_type e_nmi, estado_type e_i5, estado_type e_i12, estado_type i12_i5);

/*!
 * @brief Ativado ao pressionar qualquer bot�o, aguarda um tempo para garantir que n�o
 * haver� acionamento duplo
*/
void SysTick_Handler(void);

/*!
 * @brief Chamado quando h� algum presionamento de bot�o
*/
void PORTA_IRQHandler (void);


#endif /* ISR_H_ */
