/*!
@file ISR.c
@brief O m�dulo cont�m fun��es de interrup��o
@author Rafael Cirino, Fernando Cillo
@date 15/05/2022
*/

#include "util.h"
#include "ISR.h"
#include "GPIO_switches.h"
#include "derivative.h"
#include "timers.h"

//Implementar depois o systick para doios bot�es simult�neos

static estado_type estado = DESLIGADO;
uint8_t percentagem = 0;
int valor;

estado_type ISR_LeEstado ()
{
	return estado;
}

uint8_t ISR_LePercentagem ()
{
	return percentagem;
}

int8_t troca_estado(estado_type e_nmi, estado_type e_i5, estado_type e_i12, estado_type i12_i5){
	int8_t j = 0;
	
	if (valor == 0x1) {
		estado = e_nmi;
		percentagem = 0;
	} else if (valor == 0x2) {
		estado = e_i5;
		j = -5;
	} else if (valor == 0x100) {
		estado = e_i12;
		j = 5;
	} else if (valor == 0x102){
		estado = i12_i5;
		percentagem = 50;
	}
	
	return j;
}

void SysTick_Handler(void){
	int8_t i = 0;
	GPIO_leSwitchesISF(&valor);
	
	switch(estado){
		case DESLIGADO:
			percentagem = 0;
			if (valor == 0x1) {
				estado = RESET;
				percentagem = 50;
			}
			break;
		case RESET:
		case DECREMENTA:
		case INCREMENTA:
			i = troca_estado(DESLIGADO, DECREMENTA, INCREMENTA, RESET);
			if ((percentagem >= 100) && (i == 5)){
				percentagem = 100;
			} else if ((percentagem <= 5) && (i == -5)){
				percentagem = 0;
			} else {
				percentagem += i;
			}
			break;
	}
	PORTA_ISFR |= 0x1030;
	SysTick_desativaInterrupt ();
}



void PORTA_IRQHandler (void){
	SysTick_ativaInterrupt ();
}
