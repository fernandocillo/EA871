/*!
@file main.c
@brief Cont�m a main do experimento 10
@author Rafael Cirino, Fernando Cillo
@date 03/06/2022
*/


#include "TPM.h"
#include "util.h"
#include "ISR.h"
#include "timers.h"
#include "GPIO_latch_lcd.h"
#include "GPIO_switches.h"
#include "string.h"


void init_modules(){
	GPIO_ativaConLatchLCD ();
	GPIO_initLCD ();
	
	GPIO_initSwitches();
	GPIO_habilitaSwitchesInterrupt(3);
	
	RTClpo_init();
	SysTick_init(5242880*2);
}

void constroiBitmaps(uint8_t* end, uint8_t n, char** symbol){
	uint8_t i;
	for (i = 0; i < n; ++i){
		GPIO_escreveBitmapLCD (end[i], symbol[i]);
	}
}

void bitmap_init(){
	char des[8] = {0x1c, 0x12, 0x11, 0x11, 0x11, 0x12, 0x1c, 0x0};
	char res[8] = {0x1e, 0x11, 0x11, 0x1e, 0x14, 0x12, 0x11, 0x0};
	char inc[8] = {0x0, 0x4, 0xe, 0x15, 0x4, 0x4, 0x4, 0x0};
	char dec[8] = {0x0, 0x4, 0x4, 0x4, 0x15, 0xe, 0x4, 0x0};
	
	uint8_t ends[5]={0x02, 0x03, 0x04, 0x05, 0x00};
	char *bit_array[4] = {des, res, inc, dec};
		
	constroiBitmaps (ends, 4, bit_array);
}

void atualiza_lcd_pwm(){
	static char str_pwm[6];
	static char str_dec[4];
	uint16_t pwm = TPM_leChValor (1, 0);
			
	*itoa(pwm, str_pwm, 10);
	uint8_t i;
	for (i = strlen(str_pwm); i <= 5; i++){
		str_pwm[i] = ' ';
	}
	
	GPIO_escreveStringLCD (0x40, str_pwm);
	
	float razao = (pwm + 0.0)/(65525 + 0.0);
	*ftoa(razao, str_dec);
	GPIO_escreveStringLCD (0x4C, str_dec);
	
	/*
	static char str_vel[6];
	float vel = (2 * 3.14)/(120 /(pwm + 0.0)); //2pi/periodo
	*ftoa(vel, str_vel);
	if (vel == 0){
		str_vel[4] = ' ';
		str_vel[5] = ' ';
		str_vel[6] = ' ';
	} else {
		for (i = strlen(str_vel); i <= 5; i++){
			str_vel[i] = ' ';
		}
	}
	GPIO_escreveStringLCD (0x04, str_vel);
	*/
}

int main(void){
	init_modules();
	
	char str_bitmaps[4] = {0x02, 0x03, 0x04, 0x05};
	bitmap_init();
	
		
	static uint8_t percen_anterior = 100;
	static uint8_t percen_atual = 0;
	static uint8_t end = 0;
	static estado_type estado_anterior = RESET;
	static estado_type estado_atual = DESLIGADO;

	TPM_initPTB0EPWM(65525, 0b101, 0, ON);
	GPIO_escreveStringLCD (0x03, "VELOCIDADE");
	
	for (;;){
		percen_atual = ISR_LePercentagem ();
		
		if (percen_atual != percen_anterior){
			estado_atual = ISR_LeEstado ();
			TPM_atualizaDutyCycleEPWM(1, 0, percen_atual);
			
			percen_anterior = percen_atual;
			atualiza_lcd_pwm();
			
			if (estado_atual != estado_anterior){
				estado_anterior = estado_atual;
				switch(estado_atual){
					case DESLIGADO:
						end = 0;
						break;
					case RESET:
						end = 1;
						break;
					case INCREMENTA:
						end = 2;
						break;
					case DECREMENTA:
						end = 3;
						break;
				}
				
				char write_bitmap[2] = {str_bitmaps[end], 0x00};
				GPIO_escreveStringLCD (0x0f, write_bitmap);
			}
		}
	}
}
