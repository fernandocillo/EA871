/*!
@file GPIO_switches.c
@brief Este m�dulo cont�m interface aos registradores de
switches no modo GPIO
@author Rafael Cirino, Fernando Cillo
@date 27/04/2022
*/

#include "derivative.h"
#include "util.h"

void GPIO_leSwitchesISF (int *valor){
	*valor = ((PORTA_ISFR & 0x1030) >> 4);
	PORTA_ISFR |= 0x1030;
}

void GPIO_habilitaSwitchesInterrupt (uint8_t priority){
	NVIC_ISER |= GPIO_PIN(46-16);            		// Habilita interrupcao PORTA
	NVIC_ICPR |= GPIO_PIN(46-16);
	NVIC_IPR7 |= NVIC_IP_PRI_30(priority << 6);    	

	// Configurar o trigger
	PORTA_PCR4 |= PORT_PCR_ISF_MASK | PORT_PCR_IRQC(0b1010);           
	
	PORTA_PCR5 |= PORT_PCR_ISF_MASK | PORT_PCR_IRQC(0b1010);          
	
	PORTA_PCR12 |= PORT_PCR_ISF_MASK | 
				PORT_PCR_IRQC(0b1010);          
	
}

void GPIO_initSwitches() {
	// Habilita o clock do modulo PORTA
	SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK;				// para botoeiras   					// para leds
	
	// Funcao GPIO PTA4
	PORTA_PCR4 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
	PORTA_PCR4 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001
	
	// Funcao GPIO PTA5
	PORTA_PCR5 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
	PORTA_PCR5 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001
	
	// Funcao GPIO PTA12
	PORTA_PCR12 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
	PORTA_PCR12 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001

	// Sentido do sinal: entrada (0x400ff014)
	GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(4)));  //PTA4
	GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(5)));  //PTA5
	GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(12))); //PTA12
}


booleano_type GPIO_amostraBotoeiraNMI (){
	// Botoeira ativa baixa (0x400ff010)
	if (!(GPIOA_PDIR & GPIO_PIN (4))) return (ON);
	else return (OFF);
}

void GPIO_amostraSwitches(int *valor){
	*valor = ((~GPIOA_PDIR & 0x1030) >> 4);
}

