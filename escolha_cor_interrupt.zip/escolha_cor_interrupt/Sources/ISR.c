/*!
@file ISR.c
@brief   O m�dulo cont�m as rotinas de servi�o customizadas pelo aplicativo
@author <Fernando Teodoro de Cillo>
@date <18/07/2022>
*/
#include "derivative.h"
#include "GPIO_switches.h"

uint8_t estado;

uint8_t ISR_LeEstado ()
{
	return estado;
}


