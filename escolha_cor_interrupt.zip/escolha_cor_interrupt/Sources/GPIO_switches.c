/*!
@file GPIO_switches.c
@brief   Este   m�dulo   cont�m   interface   aos   registradores   de
switches no modo GPIO
@author <Fernando Teodoro de Cillo>
@date <18/07/2022>
*/


#include "derivative.h" 
#include "GPIO_switches.h"
#include "util.h"

uint8_t estado;

void GPIO_initBotoeiraNMI () {
	// Habilita o clock do modulo PORTA
	SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK;				// para botoeiras   					// para leds

	// Funcao GPIO
	PORTA_PCR4 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
	PORTA_PCR4 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001

	// Sentido do sinal: entrada (0x400ff014)
	GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(4)));    
}

void GPIO_initSwitches(){
// Habilita o clock do modulo PORTA
		SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK;				// para botoeiras   					// para leds

//NMI
		// Funcao GPIO
		PORTA_PCR4 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
		PORTA_PCR4 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001

		// Sentido do sinal: entrada (0x400ff014)
		GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(4))); 
		
//IRQ5
		// Funcao GPIO
		PORTA_PCR5 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
		PORTA_PCR5 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001

		// Sentido do sinal: entrada (0x400ff014)
		GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(5)));
				
//IRQ12
		// Funcao GPIO
		PORTA_PCR12 &= ~PORT_PCR_MUX(0x7);			// limpar os bits (0x40049010)
		PORTA_PCR12 |= PORT_PCR_MUX(0x1);			// antes de setar 0b001

		// Sentido do sinal: entrada (0x400ff014)
		GPIOA_PDDR &= ~(GPIO_PDDR_PDD(GPIO_PIN(12)));
}



void GPIO_habilitaSwitchesInterrupt(uint8_t priority){
	NVIC_ISER |= GPIO_PIN(30);            		// Habilita interrupcao PORTA
		NVIC_ICPR |= GPIO_PIN(30);
		NVIC_IPR7 |= NVIC_IP_PRI_30(priority << 6);    	

		// Configurar o trigger nos pinos 4, 5 e 12
		PORTA_PCR4 |= PORT_PCR_ISF_MASK | 
				PORT_PCR_IRQC(0b1010); // 0b1010 = borda de descida          
		
		PORTA_PCR5 |= PORT_PCR_ISF_MASK | 
						PORT_PCR_IRQC(0b1010);  
		
		PORTA_PCR12 |= PORT_PCR_ISF_MASK | 
						PORT_PCR_IRQC(0b1010);  
}
