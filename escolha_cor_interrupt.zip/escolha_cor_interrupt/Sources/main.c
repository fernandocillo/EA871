/*!
@file main.c
@brief   O m�dulo acende LEDs pelo m�todo de interrup��o.
@author  <Fernando Teodoro de Cillo>
@date <18/07/2022>
*/
#include "derivative.h" /* include peripheral declarations */
#include "stdint.h" /* necess�rio para o uso do tipo uint8_t*/ 
#include "GPIO_switches.h"
#include "GPIO_ledRGB.h"
#include "ISR.h"
#include "util.h"

uint8_t estado = 0;
void PORTA_IRQHandler(){
	uint8_t cor[9]={0b001, 0b011, 0b101, 0b010, 0b011, 0b110, 0b100, 0b101,0b110};
	//NMI
	if (!(PORT_PCR_ISF_MASK & PORTA_PCR4)){
		PORTA_PCR4 |= PORT_PCR_ISF_MASK;
		
		switch (estado){
					case 0:
						estado = 1;
					break;
				
					case 1:
						estado = 2;
				break;
					
					case 2:
						estado = 0;
					break;
					
					case 3:
						estado = 0;
					break;
					
					case 4:
					estado = 1;
					break;
					
				case 5:
						estado= 2;
					break;
					
				case 6:
						estado=0;
				break;
					
					case 7:
						estado=1;
					break;
					
					case 8:
						estado=2;
				break;
				
					}
		ativa_cor (cor[estado]);
	}
	//IRQA5
	else if (!(PORT_PCR_ISF_MASK & PORTA_PCR5)){

		PORTA_PCR5 |= PORT_PCR_ISF_MASK;
		
		switch (estado){
		case 0:
		estado=3;
		break;
		
		case 1:
		estado=4;
		break;
					
					case 2:
						estado=5;
				break;
					
					case 3:
						estado=4;
					break;
					
					case 4:
						estado=5;
					break;
					
					case 5:
						estado=3;
					break;
					
					case 6:
						estado=3;
		break;
					
					case 7:
						estado=4;
					break;
					
					case 8:
						estado=5;
					break;
					
					}
		ativa_cor (cor[estado]);
		}
	//IRQA12
	else if (!(PORT_PCR_ISF_MASK & PORTA_PCR12)){

		PORTA_PCR12 |= PORT_PCR_ISF_MASK;
		
		switch (estado){
		case 0:
						estado=6;
					break;
					
				case 1:
						estado=7;
					break;
					
					case 2:
					estado=8;
					break;
					
					case 3:
					estado=6;
				break;
					
					case 4:
						estado=7;
					break;
					
					case 5:
						estado=8;
				break;
				
					case 6:
						estado=7;
					break;
					
					case 7:
						estado=8;
					break;
					
					case 8:
						estado=6;
					break;
					
					}
		ativa_cor (cor[estado]);
	}
	
	PORTA_ISFR |= 0x1030;

//	switch (estado){
//			case 0:
//				amostra_switches(&estado, 1 ,3, 6);
//			break;
//			
//			case 1:
//				amostra_switches(&estado, 2, 4, 7);
//			break;
//			
//			case 2:
//				amostra_switches(&estado, 0, 5, 8);
//			break;
//			
//			case 3:
//				amostra_switches(&estado, 0, 4, 6);
//			break;
//			
//			case 4:
//				amostra_switches(&estado, 1, 5, 7);
//			break;
//			
//			case 5:
//				amostra_switches(&estado, 2, 3, 8);
//			break;
//			
//			case 6:
//				amostra_switches(&estado, 0, 3, 7);
//			break;
//			
//			case 7:
//				amostra_switches(&estado, 1, 4, 8);
//			break;
//			
//			case 8:
//				amostra_switches(&estado, 2, 5, 6);
//			break;
//			
//			}
}

int main (void){
	GPIO_initSwitches();
	GPIO_habilitaSwitchesInterrupt(3);
	GPIO_initLedRGB();
	for(;;) 
	{
	}
	return 0;
}

