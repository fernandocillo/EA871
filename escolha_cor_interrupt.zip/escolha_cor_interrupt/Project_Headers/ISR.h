/*
 * ISR.h
 *
 *  Created on: May 11, 2022
 *      Author: ea871
 */

#ifndef ISR_H_
#define ISR_H_

uint8_t amostra_switches (int estado, int NMI, int IRQA5, int IRQA12);

void PORTA_IRQHandler (void);

uint8_t ISR_LeEstado ();

#endif /* ISR_H_ */
