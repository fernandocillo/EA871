/**
 * @file util.h
 * @brief Prototipo das funcoes utilitarias
 * @author Wu Shin Ting
 * @date 23/04/2022
 */

#ifndef UTIL_H_
#define UTIL_H_

#define GPIO_PIN(x)  ((1)<<(x))

/**
 * @brief Dois estados booleanos
 */
typedef enum boolean_tag {
	OFF,     /**< falso/apaga/desativa/liga */
	ON      /**< verdadeiro/acende/ativa/fecha */
} booleano_type;

/**
 * @brief atraso em numero de interacoes i
 * @param[in] i numero de iteracoes
 */
void delay (unsigned int i);

/**
 * @brief atraso em multiplos de 10us
 * @param[in] i multiplos
 */
void delay_10us (unsigned int i);

void ativa_cor (int cor_estado);

#endif /* UTIL_H_ */
