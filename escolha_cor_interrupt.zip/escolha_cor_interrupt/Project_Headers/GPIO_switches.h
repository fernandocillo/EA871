/**
 * @file GPIO_switches.h
 */
//Ting: Doxgen segue uma certa regra de documentacao. Veja o link: 
// https://www.doxygen.nl/manual/docblocks.html
/*
 * GPIO_switches.h
 *
 *  Created on: May 2, 2022
 *      Author: ea871
 */

#ifndef GPIO_SWITCHES_H_
#define GPIO_SWITCHES_H_

#include "util.h"
#include "stdint.h"

void GPIO_initBotoeiraNMI ();

void GPIO_initSwitches();

void GPIO_amostraSwitches (unsigned int *valor);

void GPIO_habilitaSwitchesInterrupt(uint8_t priority);

#endif /* GPIO_SWITCHES_H_ */
