/*!
	@file main.c
	@brief Cont�m a main do experimento 12
	@author Rafael Cirino, Fernando Cillo
	@date 16/06/2022
*/


#include "TPM.h"
#include "util.h"
#include "ISR.h"
#include "timers.h"
#include "GPIO_latch_lcd.h"

void main_init(){
	SIM_setaOUTDIV4(0b0001);
	
	GPIO_ativaConLatchLCD ();
	GPIO_initLCD ();
	
	TPM_initSwitchIRQA5LedB (32767, 0b111);
	TPM_habilitaSwitchIRQA5LedbBInterrupt (1);
	
	char cronometro[8] = {0x11, 0xe, 0x15, 0x15, 0x1d, 0x11, 0xe, 0x0};
	GPIO_escreveBitmapLCD (0x02, cronometro);
	
}

int main( void)
{
	main_init();
	
	char write_bitmap[2] = {0x02, 0x00};
	
	estado_type estado = ISR_LeEstado();
	char string[8];
	
	unsigned short valor[3];
	int seg;
	float tempo;
	for(;;) 
	{
		estado = ISR_LeEstado();
		
		switch(estado){
			case ESPERA:
			case CONTAGEM:
			case LEITURA:
				break;
			case REALIMENTACAO:
				ISR_LeSegundos (&seg);
				itoa(seg, string, 10);
				
				GPIO_escreveStringLCD (0x41, string);
				
				ISR_AtualizaEstado(CONTAGEM);
				break;
			case INTERVALO:
				ISR_LeValoresAmostrados(valor);
				ComputaIntervaloTempo (valor[0], valor[1], valor[2], &tempo);
				ftoa(tempo, string);
				
				GPIO_escreveStringLCD (0x0f, write_bitmap);
				GPIO_escreveStringLCD (0x41, string);

				ISR_AtualizaEstado(LEITURA);
				break;
			case RESETA_VISOR:
				GPIO_escreveStringLCD (0x0f, " ");
				GPIO_escreveStringLCD (0x41, "        ");
				ISR_AtualizaEstado(ESPERA);
				break;
		}
	}
	return 1;
}
