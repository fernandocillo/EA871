/*!
	@file ISR.c
	@brief Este modulo contem declaracoes relacionadas com o modulo ISR.c
	@author Rafael Cirino, Fernando Cillo
	@date 16/06/2022
*/


#include "derivative.h"
#include "TPM.h"
#include "ISR.h"

static estado_type estado = ESPERA;
unsigned short t1;
unsigned short t2;
static unsigned short multiplos;

int segundos = 0;

estado_type ISR_LeEstado() {
	return estado;
}

void ISR_AtualizaEstado (estado_type novo) {
	estado = novo;
	
	return;
}

void ISR_LeValoresAmostrados (unsigned short *v) {
	v[0] = t1;
	v[1] = t2;
	v[2] = multiplos;
	
	return;
}

void ISR_LeSegundos (int *seg) {
	*seg = segundos;
	
	return;
}

void FTM0_IRQHandler () {
	static unsigned short counter;
	unsigned short valor;
	
	if (TPM0_STATUS & TPM_STATUS_CH2F_MASK) {
		valor = TPM0_C2V;
		if (estado == ESPERA) {
			t1 = valor;
			
			TPM0_C1SC |= TPM_CnSC_CHF_MASK; 	    // baixar bandeira (w1c)
			TPM0_C1SC |= TPM_CnSC_CHIE_MASK; 	    // habilitar interrupcao do TPM0_CH2
			TPM0_C1V = TPM_CnV_VAL(valor);   		// seta o valor de match em TPM0_CH2
			counter = 0;								//  contador de ciclos intervalo
			
			TPM_ativaLedB (0b10, 0);
			ISR_AtualizaEstado(CONTAGEM);
			
		} else if ((estado == CONTAGEM) || (estado == REALIMENTACAO)) {
			t2 = valor;
			
			multiplos = counter;
			counter = 0;
		
			ISR_AtualizaEstado(INTERVALO);
		}

		TPM0_C2SC |= TPM_CnSC_CHF_MASK;     	// limpar solicitacao da chave     
	} else if (TPM0_STATUS & TPM_STATUS_CH1F_MASK) {
		counter++;								// incrementar counter
		
		if ((estado == CONTAGEM) && ((counter/5) > segundos)){
			segundos = counter/5;
			ISR_AtualizaEstado(REALIMENTACAO);
		} else if ((estado == LEITURA) && ((counter * 0.25) >= 5)){
			TPM_desativaCh (0, 1);
			segundos = 0;
			ISR_AtualizaEstado(RESETA_VISOR);
		}
		TPM0_C1SC |= TPM_CnSC_CHF_MASK;     	// limpar solicitacao de Output Compare  
	} 
}
