/*!
 * @file TPM.c
 * @brief Este modulo contem interface dos TPMx.
 * @author Wu Shin Ting
 * @date 01/03/2022
 */

#include "derivative.h"
#include "TPM.h"

static TPM_MemMapPtr TPM[] = TPM_BASE_PTRS;
static PORT_MemMapPtr PORT[] = PORT_BASE_PTRS;

void TPM_initH5Pin12EPWM (uint16_t periodo, uint8_t ps, uint8_t percentagem, booleano_type mode) {
	
	TPM_init (2, periodo, ps);
	
	/*!
	 * Configura a funcao dos pinos em TPM
	 */
	SIM_SCGC5 |= SIM_SCGC5_PORTE_MASK; 			///< \li \l habilita clock de PORTE                           	
	PORT_PCR_REG(PORT[4],22) |= (PORT_PCR_ISF_MASK |			///< \li \l PTE22 em TPM2_CH0 (H5, pino 2)
				  PORT_PCR_MUX(0x3) );       
	PORT_PCR_REG(PORT[4],23) |= (PORT_PCR_ISF_MASK |			///< \li \l PTE23 em TPM2_CH1 (H5, pino 1)
				  PORT_PCR_MUX(0x3) );      

	/*!
	 * Configura os canais para gerarem EPWM (edge-aligned PWM): 0b1010 (High) ou 0b10X1 (Low) 
	 * Configura o valor de match inicial
	 */
	TPM_initChEPWM (2, 0, percentagem, mode);
	TPM_initChEPWM (2, 1, percentagem, mode);

}

void TPM_atualizaDutyCycleH5Pin2 (uint8_t percentagem)
{

	TPM_CnV_REG(TPM[2],0) = TPM_CnV_VAL(percentagem*0.01*(TPM2_MOD+1));   		///< atuqaliza o valor de match

}

void TPM_atualizaDutyCycleH5Pin1 (uint8_t percentagem)
{

	TPM_CnV_REG(TPM[2],1) = TPM_CnV_VAL(percentagem*0.01*(TPM[2]->MOD+1));   		///< atuqaliza o valor de match

}

void TPM_init (uint8_t x, uint16_t periodo, uint8_t ps) {
	
	SIM_SCGC6 |= GPIO_PIN(24+x); 	///< \li \l habilita clock de TPMx                           	

	/**
	 * Fonte de CLK de TPM: TPMSRC=SIM_SOPT2[25:24]=01 (MCGFLLCLK|MCGPLLCLK/2)
	 * PLLFLLSEL=SIM_SOPT2[16]=0 (MCGFLLCLK) 
	 */
	SIM_SOPT2 |= SIM_SOPT2_TPMSRC(0b01);     ///< \li \l seleciona fonte de clock TPM
	SIM_SOPT2 &= ~SIM_SOPT2_PLLFLLSEL_MASK;  	

	TPM[x]->SC &= ~TPM_SC_CMOD(0x3);		///< desabilita contador

	TPM[x]->SC &= ~(TPM_SC_TOIE_MASK |		///< \li \l desabilita interrupcao "overflow"
				TPM_SC_CPWMS_MASK); 	///< \li \l modo de contagem crescente

	TPM[x]->MOD &= TPM_MOD_MOD(periodo);    	///< \li \l seta contagem maxima
	
	TPM[x]->SC &= ~TPM_SC_PS(0b111);       ///< \li \l seta prescaler 
	TPM[x]->SC |= TPM_SC_PS(ps);         	

	TPM[x]->CNT |= TPM_CNT_COUNT(0x0)  ;   ///< \li \l reseta a contagem com base em LPTPM
	
	TPM[x]->SC |= TPM_SC_CMOD(0x1);		///< \li \l habilita contador 
}

void TPM_initChEPWM (uint8_t x, uint8_t n, uint8_t percentagem, booleano_type mode) {
	/*!
	 * Configura os canais para gerarem EPWM (edge-aligned PWM): 0b1010 (High) ou 0b10X1 (Low) 
	 */
	TPM_CnSC_REG(TPM[x],n) &= ~(TPM_CnSC_MSB_MASK |  // MSB=TPMx_CnSC[5]=0
			TPM_CnSC_MSA_MASK |         // MSA=TPMx_CnSC[4]=0
			TPM_CnSC_ELSB_MASK |        // ELSB=TPMx_CnSC[3]=0
			TPM_CnSC_ELSA_MASK );       // ELSA=TPMx_CnSC[2]=0

	if (mode == ON) { //High-true
		TPM_CnSC_REG(TPM[x],n) |= (TPM_CnSC_MSB_MASK |       // MSB=TPMx_CnSC[5]=1
				TPM_CnSC_ELSB_MASK );     		// ELSB=TPMx_CnSC[3]=1
	} else if (mode == OFF) { //Low-true
		TPM_CnSC_REG(TPM[x],n) |= (TPM_CnSC_MSB_MASK |       // MSB=TPMx_CnSC[5]=1
				TPM_CnSC_ELSA_MASK );     		// ELSB=TPMx_CnSC[2]=1
	}
	
	/*!
	 * Configura o valor de match inicial
	 */
	TPM_CnV_REG(TPM[x],n) = TPM_CnV_VAL(percentagem*0.01*(TPM[x]->MOD+1)); // TPMx_CnV	
}

void TPM_atualizaPolaridadeEPWM (uint8_t x, uint8_t n, booleano_type mode)
{
	TPM_CnSC_REG(TPM[x],n) &= ~(TPM_CnSC_MSB_MASK |      ///< desabilita canal TPM2_CH1
			TPM_CnSC_MSA_MASK |         
			TPM_CnSC_ELSB_MASK |        
			TPM_CnSC_ELSA_MASK );       

	if (mode == ON) 						///< reabilita o canal no modo HIGH
		TPM_CnSC_REG(TPM[x],n) |= (TPM_CnSC_MSB_MASK |      
				TPM_CnSC_ELSB_MASK );     
	else if (mode == OFF) 					///< reabilita o canal no modo LOW
		TPM_CnSC_REG(TPM[x],n) |= (TPM_CnSC_MSB_MASK |       
				TPM_CnSC_ELSA_MASK );     		
}

void TPM_initSwitchNMIChannelTPM0CH2 (uint32_t periodo, uint8_t ps) {

	TPM_init (0, periodo, ps);

	/*!
	 * Configura os pinos: PTA4 (entrada)
	 */
	SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK;			// habilita clock de PORTA
	PORTA_PCR4 &= ~PORT_PCR_MUX(0x4);			// PTA4 em TPM0_CH1     

	TPM_initChIC (0, 1, 0b10);
	TPM_initChOC (0, 2, 0b10, 0);
}

void TPM_initSwitchIRQA5LedB (uint32_t periodo, uint8_t ps) {

	TPM_init (0, periodo, ps);
	/*!
	 * Configura os pinos: PTA5 (entrada)
	 */
	SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK;			// habilita clock de PORTA
	
	PORTA_PCR4 &= ~PORT_PCR_MUX(0x7);			// PTA5 em TPM0_CH1     
	PORTA_PCR5 |= PORT_PCR_MUX(0x3);			// PTA5 em TPM0_CH1     

	//LedB
	// Modulo SIM: habilita o clock do modulo PORTn
	SIM_SCGC5 |= SIM_SCGC5_PORTD_MASK;
	
	PORTD_PCR1 |= PORT_PCR_MUX(0x4);

	TPM_initChIC (0, 2, 0b10);
	TPM_desativaCh (0, 1);
}

void TPM_initChIC (uint8_t x, uint8_t n, uint8_t mode) {
	/*!
	 * Configura os canais para operar no modo Input Capute mode (0b01, 0b10 e 0b11)
	 */
	TPM_CnSC_REG(TPM[x],n) &= ~(TPM_CnSC_MSB_MASK |  // MSB=TPMx_CnSC[5]=0
			TPM_CnSC_MSA_MASK |         // MSA=TPMx_CnSC[4]=0
			TPM_CnSC_ELSB_MASK |        // ELSB=TPMx_CnSC[3]=0
			TPM_CnSC_ELSA_MASK );       // ELSA=TPMx_CnSC[2]=0

	TPM_CnSC_REG(TPM[x],n) |= (mode << 2);      // rising/falling/both edges
}

void TPM_initChOC (uint8_t x, uint8_t n, uint8_t mode, uint16_t valor) {
	/*!
	 * Configura os canais para operar no modo Output Compare mode (0b01, 0b10, 0b11)  
	 */
	TPM_CnSC_REG(TPM[x],n) &= ~(TPM_CnSC_MSB_MASK |  // MSB=TPM0_C2SC[5]=0
			TPM_CnSC_MSA_MASK |         // MSA=TPM0_C2SC[4]=0
			TPM_CnSC_ELSB_MASK |        // ELSB=TPM0_C2SC[3]=0
			TPM_CnSC_ELSA_MASK );       // ELSA=TPM0_C2SC[2]=0
	/*!
	 * Setar o valor em TPMx_CnV
	 */
	TPM_CnV_REG(TPM[x],n) = TPM_CnV_VAL(valor); 

	TPM_CnSC_REG(TPM[x],n) |= (TPM_CnSC_MSA_MASK |   // MSA=TPM0_C2SC[4]=1
								(mode << 2));      	// toggle/clear/set output
}

void TPM_ativaLedB (uint8_t mode, uint16_t valor){
	TPM_initChOC (0, 1, 0b01, 0);
}

void TPM_habilitaSwitchNMIChannelTPM0CH2Interrupt (char priority) {	
    NVIC_ISER |= 1 << (17);              // NVIC_ISER[17]=1 (habilita IRQ17)
    NVIC_ICPR |= 1 << (17);              // NVIC_ICPR[17]=1 (limpa as pendências)
    NVIC_IPR4 |= NVIC_IP_PRI_17(priority << 6);    
    
	/*!
	 * Habilitar o evento de interrupcao
	 */ 
	//TPM_CnSC_REG(TPM[0],1) |= TPM_CnSC_CHF_MASK;      	// limpar pendencias 	
	//TPM_CnSC_REG(TPM[0],1) |= TPM_CnSC_CHIE_MASK; 	    // habilitar interrupcao do canal 1	

	TPM_CnSC_REG(TPM[0],2) |= TPM_CnSC_CHF_MASK;      	// limpar pendencias 	
	TPM_CnSC_REG(TPM[0],2) |= TPM_CnSC_CHIE_MASK; 	    // habilitar interrupcao do canal 2	
}

void TPM_habilitaSwitchIRQA5LedbBInterrupt (char priority) {	
	NVIC_ISER |= 1 << (17);              // NVIC_ISER[17]=1 (habilita IRQ17)
	NVIC_ICPR |= 1 << (17);              // NVIC_ICPR[17]=1 (limpa as pendências)
	NVIC_IPR5 |= NVIC_IP_PRI_17(priority << 6);          
    
	/*!
	 * Habilitar o evento de interrupcao
	 */ 
	TPM_CnSC_REG(TPM[0],1) |= TPM_CnSC_CHF_MASK;      	// limpar pendencias 	
	TPM_CnSC_REG(TPM[0],1) |= TPM_CnSC_CHIE_MASK; 	    // habilitar interrupcao do canal 1	

	TPM_CnSC_REG(TPM[0],2) |= TPM_CnSC_CHF_MASK;      	// limpar pendencias 	
	TPM_CnSC_REG(TPM[0],2) |= TPM_CnSC_CHIE_MASK; 	    // habilitar interrupcao do canal 2	
}

void TPM_ativaSwitchNMIInterrupt () {
	TPM0_C1SC |= TPM_CnSC_CHF_MASK;      	// limpar pendencias 	
	TPM_CnSC_REG(TPM[0],1) |= TPM_CnSC_CHIE_MASK; 	    // ativa interrupcao do canal 1		
}

void TPM_desativaSwitchNMIInterrupt () {
	TPM0_C1SC &= ~TPM_CnSC_CHIE_MASK; 	    // desativa interrupcao do canal 1		
}

void TPM_ativaChannelTPM0CH2Interrupt () {
	TPM_CnSC_REG(TPM[0],2) |= TPM_CnSC_CHF_MASK;      	// limpar pendencias 	
	TPM0_C2SC |= TPM_CnSC_CHIE_MASK; 	    // ativa interrupcao do canal 2		
}

void TPM_desativaChannelTPM0CH2Interrupt () {
	TPM0_C2SC &= ~TPM_CnSC_CHIE_MASK; 	    // desativa interrupcao do canal 2		
}

void TPM_desativaCh (uint8_t x, uint8_t n) {
	TPM_CnSC_REG(TPM[x],n) &= ~(TPM_CnSC_MSB_MASK |  // MSB=TPM0_C2SC[5]=0
			TPM_CnSC_MSA_MASK |         // MSA=TPM0_C2SC[4]=0
			TPM_CnSC_ELSB_MASK |        // ELSB=TPM0_C2SC[3]=0
			TPM_CnSC_ELSA_MASK );       // ELSA=TPM0_C2SC[2]=0
}
