/*!
@file main.h
@brief Cont�m a main do experimento 12
@author Rafael Cirino, Fernando Cillo
@date 16/06/2022
*/

#ifndef MAIN_H_
#define MAIN_H_


/*!
 * @brief Configura��es inciais do programa
 */
void main_init();

/*!
 * @brief Programa do roteiro 11
 */
int main();

#endif /* MAIN_H_ */
