/*!
 * @file TPM.h
 * @brief Este modulo contem declaracoes relacionadas com o modulo TPM.c
 * @author Wu Shin Ting
 * @date 03/03/2022
 */

#ifndef TPM_H_
#define TPM_H_

#include "stdint.h"
#include "util.h"

/*!
 * @brief Configura o temporizador TPM0 com um valor MOD. 
 * @param[in] periodo contagem maxima
 * @param[in] ps divisor de frequencia (prescaler)
 * 
 * @note A base de tempo assincrono do contador eh MCGFLLCLK 
 * (Ver Secao 31.4.8.1 de KL25 Sub-Family Reference Manual)
 */
void TPM_initSwitchIRQA5LedB (uint32_t periodo, uint8_t ps);

/**
 * @brief Ativa led azul
 * @param[in] valor; valor de comparacao
 * @param[in] mode: polaridade (high-true/low-true pulses)
 */
void TPM_ativaLedB (uint8_t mode, uint16_t valor);

/**
 * @brief Habilita (IRQA5, LedB) e setar prioridade 
 * @param[in] priority prioridade de atendimento
 */
void TPM_habilitaSwitchIRQA5LedbBInterrupt (char priority);



/*!
 * @brief Inicializa pinos 1 (TPM2_CH1) e 2 (TPM2_CH0). 
 * @param[in] mod contagem maxima
 * @param[in] ps divisor de frequencia (prescaler)
 * @param[in] percentagem da contagem maxima
 * @param[in] mode polaridade
 * 
 * @note A base de tempo assincrono do contador eh MCGFLLCLK 
 * (Ver Secao 31.4.8.1 de KL25 Sub-Family Reference Manual)
 */
void TPM_initH5Pin12EPWM (uint16_t periodo, uint8_t ps, uint8_t percentagem, booleano_type modo);

/**
 * @brief Atualizar a largura do PWM no pino 2 do H5
 * @param[in] valor duty cycle
 */
void TPM_atualizaDutyCycleH5Pin2 (uint8_t valor);

/**
 * @brief Atualizar a largura do PWM no pino 1 do H5
 * @param[in] valor duty cycle
 */
void TPM_atualizaDutyCycleH5Pin1 (uint8_t valor);

/**
 * @brief Inicialia modulo TPM
 * @param[in] unidado do modulo
 * @param[in] periodo
 * @param[in] ps pre-scale
 */
void TPM_init (uint8_t x, uint16_t periodo, uint8_t ps);

/**
 * @brief Inicializar um canal n do TPMx com funcao EPWM 
 * @param[in] x unidade de TPM
 * @param[in] n canal 
 * @param[in] percentagem duty cycle
 * @param[in] mode polaridade (ativo-alto ou ativo-baixo)
 */
void TPM_initChEPWM (uint8_t x, uint8_t n, uint8_t percentagem, booleano_type mode);

/**
 * @brief Atualiar a largura do PWM no canal do tpm especificados
 * @param[in] x unidade do tpm
 * @param[in] n canal
 * @param[in] mode polaridade (high-true/low-true pulses)
 */
void TPM_atualizaPolaridadeEPWM (uint8_t x, uint8_t n, booleano_type mode);

/*!
 * @brief Configura o temporizador TPM0 com um valor MOD. 
 * @param[in] mod contagem maxima
 * @param[in] ps divisor de frequencia (prescaler)
 * 
 * @note A base de tempo assincrono do contador eh MCGFLLCLK 
 * (Ver Secao 31.4.8.1 de KL25 Sub-Family Reference Manual)
 */
void TPM_initSwitchNMIChannelTPM0CH2 (uint32_t mod, uint8_t ps);


/*!
 * @brief Configura o canal n do temporizador TPMx em IC. 
 * @param[in] x modulo TPM
 * @param[in] n canal
 * @param[in] mode modo de operacao em codigo binario (borda de subida, descida ou ambas)
 */ 
void TPM_initChIC (uint8_t x, uint8_t n, uint8_t mode);

/*!
 * @brief Ativa/Inicializa o canal n do temporizador TPMx em OC. 
 * @param[in] x modulo TPM
 * @param[in] n canal
 * @param[in] mode modo de operacao em codigo binario (alternado, 0 ou 1)
 * @param[in] valor valor de comparacao
 */ 
void TPM_initChOC (uint8_t x, uint8_t n, uint8_t mode, uint16_t valor);

/**
 * @brief Habilita IRQ do par (NMI,TPM0CH2) no NVIC e setar prioridade 
 * @param[in] priority prioridade de atendimento
 */
void TPM_habilitaSwitchNMIChannelTPM0CH2Interrupt (char priority);

/**
 * @brief Ativa a interrupcao da chave NMI
 */
void TPM_ativaSwitchNMIInterrupt ();

/**
 * @brief Desativa a interrupcao da chave NMI
 */
void TPM_desativaSwitchNMIInterrupt ();

/**
 * @brief Ativa a interrupcao do canal TPM0CH2
 */
void TPM_ativaChannelTPM0CH2Interrupt ();

/**
 * @brief Desativa a interrupcao do canal TPM0CH2
 */
void TPM_desativaChannelTPM0CH2Interrupt ();

/**
 * @brief Desativa o canal TPMxCHn
 */
void TPM_desativaCh (uint8_t x, uint8_t n);

#endif /* TPM_H_ */
