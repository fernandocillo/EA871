/*!
	@file ISR.h
	@brief Este modulo contem declaracoes relacionadas com o modulo ISR.c
	@author Rafael Cirino, Fernando Cillo
	@date 16/06/2022
*/

#ifndef ISR_H_
#define ISR_H_

typedef enum state_tag {
	ESPERA,
	CONTAGEM,
	REALIMENTACAO,
	INTERVALO,
	LEITURA,
	RESETA_VISOR
} estado_type;

/*!
 * @brief Le o estado do aplicativo
 */
estado_type ISR_LeEstado ();

/*!
 * @brief Atualiza o estado do aplicativo
 * @param[in] novo estado
 */
void ISR_AtualizaEstado (estado_type novo);

/*!
 * @brief Le o valor amostrado em ADC0_RA
 * @param[in] v: Armazena o valor amostrado
 */
void ISR_LeValoresAmostrados (unsigned short *v);

/*!
 * @brief Le os segundos decorridos no programa
 * @param[in] seg: Armazena o valor
 */
void ISR_LeSegundos (int *seg);

#endif /* ISR_H_ */
